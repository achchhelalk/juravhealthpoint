<?php

session_start();
unset($_SESSION["id"]);
unset($_SESSION["username"]);
        session_destroy();
       	echo "<script>alert('Sussefully logout')</script>";
	echo "<script>window.open('index.php','_self')</script>";
   
?>