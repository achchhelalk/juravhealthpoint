<?php include("header.php"); ?>

<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->

<body>
  <!--header-->
  <section class="w3l-header">
    <header id="site-header" class="">
      <section class="w3l-top-header py-3">
        <div class="container">
          <div class="d-grid main-top">
            <div class="top-header-left">
              <ul class="info-top-gridshny">
                <li class="info-grid"                             
              </ul>
            </div>
            <div class="top-header-right text-lg-right">
             
            </div>
          </div>
        </div>
      </section>
      <div class="header-2hny py-3">
        <div class="container">
          <nav class="navbar navbar-expand-lg navbar-dark stroke">
           
            <!-- if logo is image enable this   
    <a class="navbar-brand" href="#index.html">
        <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
    </a> -->
            <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
              data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
              aria-label="Toggle navigation">
              <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
              <span class="navbar-toggler-icon fa icon-close fa-times"></span>
              </span>
            </button>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
              
              <ul class="navbar-nav search-right mt-lg-0 mt-2">
                
                  <!-- //modal-popup-->
                  <div class="selectpackage">

                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
                      aria-hidden="true">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              &times;</button>
                            <h4 class="modal-title" id="myModalLabel">
                              Make An Appointment</h4>
                          </div>
                          <div class="modal-body packages">
                            <div class="appointment-form">
                              <form action="#" method="post">
                                <div class="fields-grid">
                                  <div class="styled-input">

                                    <div class="appointment-form-field">

                                      <input type="text" name="fullname" placeholder="Full Name" required="">
                                    </div>
                                  </div>
                                  <div class="styled-input">

                                    <div class="appointment-form-field">

                                      <input type="text" name="phone" placeholder="Enter Number" required="">
                                    </div>
                                  </div>

                                  <div class="styled-input">

                                    <div class="appointment-form-field">

                                      <input type="text" name="age" placeholder="Enter Your Age" required="">
                                    </div>
                                  </div>
                                  <div class="styled-input">

                                    <div class="appointment-form-field">

                                      <input type="text" name="Address" placeholder="Enter Your Address" required="">
                                    </div>
                                  </div>
								  <div class="styled-input">

                                    <div class="appointment-form-field">

                                      <input type="text" name="Payment" placeholder="Enter Your Payemnt Detail" required="">
                                    </div>
                                  </div>
                                  <div class="styled-input">

                                    <div class="appointment-form-field">

                                      <select id="department" required="Specialization">
                                        <option value="">Specialization*</option>
                                        <option value="">Cardiology</option>
                                        <option value="">Heart Surgery</option>
                                        <option value="">Skin Care</option>
                                        <option value="">Body Check-up</option>
                                        <option value="">Numerology</option>
                                        <option value="">Diagnosis</option>
                                        <option value="">Others</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="styled-input">

                                    <div class="appointment-form-field">

                                      <select id="doctor" required="Select Doctor">
                                        <option value="">Select Doctor</option>
                                        <option value="">Doctor 1</option>
                                        <option value="">Doctor 2</option>
                                        <option value="">Doctor 3</option>
                                        <option value="">Doctor 4</option>
                                        <option value="">Doctor 5</option>
                                        <option value="">Doctor 6</option>
                                        <option value="">Doctor 7</option>
                                      </select>
                                    </div>
                                  </div>

                                </div>
                                <div class="appointment-btn text-lg-right">
                                  <button type="submit" class="btn btn-style btn-primary mt-4">Book Appointment</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <script>
                      $('#myModal').modal('show');
                    </script>
                  </div>
                  <!-- //modal-popup-->

                </li>
              </ul>

              <!-- //toggle switch for light and dark theme -->
              <!-- search popup -->
              <div id="search" class="pop-overlay">
                <div class="popup">
                  <form action="#" method="GET" class="d-sm-flex">
                    <input type="search" placeholder="Search.." name="search" required="required" autofocus>
                    <button type="submit">Search</button>
                    <a class="close" href="#url">&times;</a>
                  </form>
                </div>
              </div>
              <!-- /search popup -->
            </div>
            <!-- toggle switch for light and dark theme -->
            <div class="mobile-position">
              <nav class="navigation">
                <div class="theme-switch-wrapper">
                  <label class="theme-switch" for="checkbox">
                    <input type="checkbox" id="checkbox">
                    <div class="mode-container py-1">
                      <i class="gg-sun"></i>
                      <i class="gg-moon"></i>
                    </div>
                  </label>
                </div>
              </nav>
            </div>
            <!-- //toggle switch for light and dark theme -->
          </nav>
        </div>
      </div>
    </header>
    <!--/header-->
  </section>
  <!--/w3l-breadcrumb-->
  
      <div class="form-41-mian section-gap mt-5">
        <div class="container">
          <div class="d-grid align-form-map">
            <div class="form-inner-cont">
              <form action="https://sendmail.w3layouts.com/submitForm" method="post" class="contact-form">
                <div class="form-top-left">

                  <input type="text" name="w3lName" id="w3lName" placeholder="Name" required="">

                  <input type="email" name="w3lSender" id="w3lSender" placeholder="Email*"
                    required="">

                  <input type="text" name="mobile" id="w3lName" placeholder="Mobile"
                    required="">

                  <input type="text" name="Adress" id="Adress" placeholder="Enter Your Address"
				  <input type="text" name="Age" id="w3lName" placeholder="Enter Your Age with gender"
                    required="">

                </div>
                <div class="form-top-righ">
                  <textarea name="w3lMessage" id="w3lMessage" placeholder="Message*"
                    required=""></textarea>
                </div>
                <div class="form-submit text-right">
                    <button type="submit" class="btn btn-style btn-primary">Submit Message</button>
                  </div>
              </form>
            </div>
      
          </div>
        </div>
      </div>
      <div class="contant11-top-bg mt-4">
        <div class="container pb-lg-5">
          <div class="d-grid contact py-lg-5 py-4">
            <div 
               
              </div>
            </div>
          </div>
        </div>
      </div>
      
  </section>
 
    <!-- move top -->
    <button onclick="topFunction()" id="movetop" title="Go to top">
      &#10548;
    </button>
    <script>
      // When the user scrolls down 20px from the top of the document, show the button
      window.onscroll = function () {
        scrollFunction()
      };

      function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          document.getElementById("movetop").style.display = "block";
        } else {
          document.getElementById("movetop").style.display = "none";
        }
      }

      // When the user clicks on the button, scroll to the top of the document
      function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
      }
    </script>
    <!-- /move top -->
  </footer>

  <!-- //copyright -->
  <!-- Template JavaScript -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/theme-change.js"></script>
  <!--/MENU-JS-->
  <script>
    $(window).on("scroll", function () {
      var scroll = $(window).scrollTop();

      if (scroll >= 80) {
        $("#site-header").addClass("nav-fixed");
      } else {
        $("#site-header").removeClass("nav-fixed");
      }
    });

    //Main navigation Active Class Add Remove
    $(".navbar-toggler").on("click", function () {
      $("header").toggleClass("active");
    });
    $(document).on("ready", function () {
      if ($(window).width() > 991) {
        $("header").removeClass("active");
      }
      $(window).on("resize", function () {
        if ($(window).width() > 991) {
          $("header").removeClass("active");
        }
      });
    });
  </script>
  <!--//MENU-JS-->

  <script src="assets/js/bootstrap.min.js"></script>

</body>

<?php include("footer.php"); ?>
  