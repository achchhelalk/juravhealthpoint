<div id="footer-sec">
        &copy; <a href="" target="_blank">2018  Design and developed By  </a>
    </div>

  <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
<script src="assets/js/ckeditor/ckeditor.js"></script>
  <script src="assets/js/bootstrap.js"></script>

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap.min.css">

<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap.min.js"></script>

<script type="text/javascript" charset="utf-8">
                $(document).ready(function() {
                    $('#example').DataTable();
                } );
            </script>


	</body>
</html>