
<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	$delete_query = $pdo->prepare("delete from camptesting where id='".$delete_id."' ");
	
	if($delete_query->execute()){
	
		echo "<script>alert('Camp Testing Has been delete')</script>";
	echo "<script>window.open('manage-camp-testing.php','_self')</script>";
	
	}
	



}




?>