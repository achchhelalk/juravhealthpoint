 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                    <?php
                    
                    error_reporting(E_ALL);
ini_set('display_errors', 1);
                    
require 'dbconfig.php';					 $e=$_GET['id'];
					 
					  $query =  $pdo->prepare("SELECT * FROM camptesting WHERE id='".$e."' ");

$query->execute();
$row = $query->fetch();
 if(isset($_POST['submit']))

{
 $name= $_POST['name'];
$mobile= $_POST['mobile'];
$gender= $_POST['gender'];
$doctor_precaution= $_POST['doctor_precaution'];
$sugar_test_result= $_POST['sugar_test_result'];
$bp_test_result= $_POST['bp_test_result'];
try
		{ 
		  		    
			$stmt = $pdo->prepare("update camptesting
			set name='".$name."' , mobile='".$mobile."' ,gender='".$gender."',
doctor_precaution='".$doctor_precaution."' ,sugar_test_result='".$sugar_test_result."',bp_test_result='".$bp_test_result."' WHERE id='".$_GET['id']."' ");
					
			if($stmt->execute()){
				
			echo "<script>alert('Camp Testing Has been inserted')</script>";
	echo "<script>window.open('manage-camp-testing.php','_self')</script>";
				
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	?>
	        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Camp Testing</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
               <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Edit Camp Testing
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                            
                             <div class="form-group">
                                            <label>Patient Name</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo $row["name"];?>" />
                                                                                  </div>
							
                                        <div class="form-group">
                                            <label>Mobile No.</label>
                                            <input class="form-control" type="text" name="mobile" value="<?php echo $row["mobile"];?>" />
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Gender</label>
                                            <select class="form-control"  name="gender" value="<?php echo $row["gender"];?>" />
											<option value="Male">Male</option>
												<option value="Female">Female</option>
											</select>
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>Doctor Precaution</label>
											  <select class="form-control"  name="doctor_precaution" value="<?php echo $row["doctor_precaution"];?>" />
											<option value="Yes">Yes</option>
												<option value="No">No</option>
											</select>
                                           
                                             </div>
                                        <div class="form-group">
                                            <label>Sugar Test Result</label>
											
                                            <input class="form-control" type="text" name="sugar_test_result" value="<?php echo $row["sugar_test_result"];?>" />
                                                                                  </div>
                                        <div class="form-group">
										
                                            <label>Bp Test Result</label>
                                            <input class="form-control" type="text" name="bp_test_result" value="<?php echo $row["bp_test_result"];?>" />
                                          
                                        </div>
                                                                                    
                                  
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>

</body>
</html>
