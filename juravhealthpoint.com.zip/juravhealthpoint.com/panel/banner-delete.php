<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	$delete_query = $pdo->prepare("delete from banner  where id='$delete_id' ");
	
	if($delete_query->execute()){
	
   	echo "<script>alert('Banner  Has been Deleted')</script>";
	echo "<script>window.open('manage-banner.php','_self')</script>";
		}
	
}

?>

