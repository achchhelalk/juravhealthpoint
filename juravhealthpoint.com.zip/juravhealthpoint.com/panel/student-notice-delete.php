<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	$delete_query = $pdo->prepare("delete from student_notice where id='$delete_id' ");
	
	if($delete_query->execute()){
	
	echo "<script>alert('notice Has been Deleted')</script>";
	echo "<script>window.open('manage-student-notice.php','_self')</script>";
		}
	



}




?>
