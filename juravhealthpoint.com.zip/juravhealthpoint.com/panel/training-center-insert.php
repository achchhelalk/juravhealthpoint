 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                     <?php
require 'dbconfig.php';
if(isset($_POST['submit']))
{
//print_r("lavlesh");
//echo "<pre>"; print_r($_POST); exit;
$vtp_code= $_POST['vtp_code'];
$vtp_name= $_POST['vtp_name'];
$center_head= $_POST['center_head'];
$contact_no= $_POST['contact_no'];
$email= $_POST['email'];
$address= $_POST['address'];
$valid_upto= $_POST['valid_upto'];
$sectora= $_POST['sectora'];
$sectorb= $_POST['sectorb'];
$sectorc= $_POST['sectorc'];
$sectord= $_POST['sectord'];
$sectore= $_POST['sectore'];
$sectorf= $_POST['sectorf'];
$sectorg= $_POST['sectorg'];
$sectorh= $_POST['sectorh'];



try
		{
			$stmt = $pdo->prepare("INSERT INTO training_center(vtp_code,vtp_name,center_head,contact_no,email,address,valid_upto,sectora,sectorb,sectorc,sectord,sectore,sectorf,sectorg,sectorh
			) VALUES(:vtp_code,:vtp_name,:center_head,:contact_no,:email,:address,:valid_upto,:sectora,:sectorb,:sectorc,:sectord,:sectore,:sectorf,:sectorg,:sectorh)");
				$stmt->bindparam(":vtp_code",$vtp_code); 
			$stmt->bindparam(":vtp_name",$vtp_name); 
		    $stmt->bindparam(":center_head",$center_head);
	      $stmt->bindparam(":contact_no",$contact_no);
			$stmt->bindparam(":email",$email);
			$stmt->bindparam(":address",$address); 
		    $stmt->bindparam(":valid_upto",$valid_upto);
			
	      $stmt->bindparam(":sectora",$sectora);
			$stmt->bindparam(":sectorb",$sectorb);
			$stmt->bindparam(":sectorc",$sectorc); 
		    $stmt->bindparam(":sectord",$sectord);
	      $stmt->bindparam(":sectore",$sectore);
			$stmt->bindparam(":sectorf",$sectorf);
			$stmt->bindparam(":sectorg",$sectorg);
			$stmt->bindparam(":sectorh",$sectorh);
			
			
			if($stmt->execute()){
				echo "<script>alert('Training Center Has been inserted')</script>";
	echo "<script>window.open('manage-training-center.php','_self')</script>";
			}
			
			else{}
					
			
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

                     
                     
                     
                     
                     
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Insert Training Center</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Training Center
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                            
							<div class="form-group">
                                            <label> Vtp code</label>
                                            <input class="form-control" type="text" name="vtp_code">
                                                                                  </div>
							
                                        <div class="form-group">
                                            <label> Vtp Name</label>
                                            <input class="form-control" type="text" name="vtp_name">
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Center Head</label>
                                            <input class="form-control" type="text" name="center_head">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>	Contact no</label>
                                            <input class="form-control" type="text" name="contact_no">
                                             </div>
                                        <div class="form-group">
                                            <label> Email</label>
                                            <input class="form-control" type="text" name="email">
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Address</label>
                                            <input class="form-control" type="text" name="address">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>	valid upto</label>
                                            <input class="form-control" type="text" name="valid_upto">
                                             </div>
											 <div class="form-group">
                                            <label>	sectora</label>
                                            <input class="form-control" type="text" name="sectora">
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Sectorb</label>
                                            <input class="form-control" type="text" name="sectorb">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>Sectorc</label>
                                            <input class="form-control" type="text" name="sectorc">
                                             </div>
											 <div class="form-group">
                                            <label> Sectord</label>
                                            <input class="form-control" type="text" name="sectord">
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Sectore</label>
                                            <input class="form-control" type="text" name="sectore">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>sectorf</label>
                                            <input class="form-control" type="text" name="sectorf">
                                             </div>
											  <div class="form-group">
                                            <label>sectorg</label>
                                            <input class="form-control" type="text" name="sectorg">
                                             </div>
					<div class="form-group">
                                            <label>sectorh</label>
                                            <input class="form-control" type="text" name="sectorh">
                                             </div>
					
                                                                                    
                                  
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>


</body>
</html>
