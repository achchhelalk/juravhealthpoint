 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                     <?php
require 'dbconfig.php';
if(isset($_POST['submit']))
{
//print_r("lavlesh");
//echo "<pre>"; print_r($_POST); exit;
$enrollment_no= $_POST['enrollment_no'];
$name= $_POST['name'];
$father_name= $_POST['father_name'];

$course= $_POST['course'];
$centers_code= $_POST['centers_code'];
$session= $_POST['session'];
$result= $_POST['result'];



try
		{
			$stmt = $pdo->prepare("INSERT INTO student_enrolment(enrollment_no,name,father_name,course,centers_code,session,result) VALUES(:enrollment_no,:name,:father_name,:course,:centers_code,:session,:result)");
			$stmt->bindparam(":enrollment_no",$enrollment_no); 
			$stmt->bindparam(":name",$name); 
		$stmt->bindparam(":father_name",$father_name);
	
		$stmt->bindparam(":course",$course);
		$stmt->bindparam(":centers_code",$centers_code); 
		$stmt->bindparam(":session",$session);
		$stmt->bindparam(":result",$result);
			
			
			
			if($stmt->execute()){
				echo "<script>alert('Student Verification no Has been inserted')</script>";
	echo "<script>window.open('manage-student-verification.php','_self')</script>";
			}
			
			else{}
					
			
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

                     
                     
                     
                     
                     
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Insert Student Enrollment</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Student Enrollment 
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                             <div class="form-group">
                                            <label> Enrollment NO.</label>
                                            <input class="form-control" type="text" name="enrollment_no">
                                                                                  </div>
                                
                                        <div class="form-group">
                                            <label> Name</label>
                                            <input class="form-control" type="text" name="name">
                                                                                  </div>
                                
                                        
                                         <div class="form-group">
                                            <label> Father</label>
                                            <input class="form-control" type="text" name="father_name">
                                                                                  </div>
																				  
											  <div class="form-group">
                                            <label> Course</label>
                                            <input class="form-control" type="text" name="course">
                                                                                  </div>									  
										  <div class="form-group">
                                            <label>Training Center </label>
                                            <input class="form-control" type="text" name="centers_code">
                                                                                  </div>
																				   <div class="form-group">
                                            <label> Session</label>
                                            <input class="form-control" type="text" name="session">
                                                                                  </div>
																				     <div class="form-group">
                                            <label> Result/Grade</label>
                                            <input class="form-control" type="text" name="result" />
                                                                                  </div>
                                  
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>


</body>
</html>
