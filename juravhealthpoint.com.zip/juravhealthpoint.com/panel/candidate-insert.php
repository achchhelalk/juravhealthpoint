 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                     <?php
require 'dbconfig.php';
if(isset($_POST['submit']))
{
	$regno					= $_POST['regno'];
	$name					= $_POST['name'];
	$father_name					= $_POST['father_name'];
	
	$dob					= $_POST['dob'];
$session						= $_POST['session'];
$course					= $_POST['course'];
$mother_name						= $_POST['mother_name'];
$branch						= $_POST['branch'];
$address					= $_POST['address'];
$percentage					= $_POST['percentage'];
$mark_obtained				= $_POST['mark_obtained'];
$total_mark				= $_POST['total_mark'];
$result					= $_POST['result'];
$subjecta				= $_POST['subjecta'];
$marka				= $_POST['marka'];
$total_marka				= $_POST['total_marka'];
$subjectb				= $_POST['subjectb'];
$markb				= $_POST['markb'];
$total_markb				= $_POST['total_markb'];
$subjectc				= $_POST['subjectc'];
$markc				= $_POST['markc'];
$total_markc				= $_POST['total_markc'];
$subjectd				= $_POST['subjectd'];
$markd				= $_POST['markd'];
$total_markd				= $_POST['total_markd'];
$subjecte				= $_POST['subjecte'];
$marke				= $_POST['marke'];
$total_marke				= $_POST['total_marke'];
$subjectf				= $_POST['subjectf'];
$markf				= $_POST['markf'];
$total_markf				= $_POST['total_markf'];
$subjectg				= $_POST['subjectg'];
$markg				= $_POST['markg'];
$total_markg				= $_POST['total_markg'];
$subjecth			= $_POST['subjecth'];
$markh			= $_POST['markh'];
$total_markh				= $_POST['total_markh'];
$subjecti				= $_POST['subjecti'];
$marki				= $_POST['marki'];
$total_marki				= $_POST['total_marki'];
$subjectj				= $_POST['subjectj'];
$markj				= $_POST['markj'];
$total_markj				= $_POST['total_markj'];

$subjectk				= $_POST['subjectk'];
$markk				= $_POST['markk'];
$total_markk				= $_POST['total_markk'];






$suba				= $_POST['suba'];
$markaa				= $_POST['markaa'];
$tota				= $_POST['tota'];
$subb				= $_POST['subb'];
$markbb				= $_POST['markbb'];
$totb				= $_POST['totb'];
$subc				= $_POST['subc'];
$markcc				= $_POST['markcc'];
$totc				= $_POST['totc'];
$subd				= $_POST['subd'];
$markdd				= $_POST['markdd'];
$totd				= $_POST['totd'];
$sube				= $_POST['sube'];
$markee				= $_POST['markee'];
$tote				= $_POST['tote'];
$subf				= $_POST['subf'];
$markff				= $_POST['markff'];
$totf				= $_POST['totf'];
$subg				= $_POST['subg'];
$markgg				= $_POST['markgg'];
$totg				= $_POST['totg'];
$subh			= $_POST['subh'];
$markhh			= $_POST['markhh'];
$toth				= $_POST['toth'];
$subi				= $_POST['subi'];
$markii				= $_POST['markii'];
$toti				= $_POST['toti'];
$subj				= $_POST['subj'];
$markjj				= $_POST['markjj'];
$totj				= $_POST['totj'];

$subk				= $_POST['subk'];
$markkeleven				= $_POST['markkeleven'];
$totk				= $_POST['totk'];



$third_suba				= $_POST['third_suba'];
$third_marka				= $_POST['third_marka'];
$third_tota				= $_POST['third_tota'];
$third_subb				= $_POST['third_subb'];
$third_markb				= $_POST['third_markb'];
$third_totb				= $_POST['third_totb'];
$third_subc				= $_POST['third_subc'];
$third_markc				= $_POST['third_markc'];
$third_totc				= $_POST['third_totc'];
$third_subd				= $_POST['third_subd'];
$third_markd				= $_POST['third_markd'];
$third_totd				= $_POST['third_totd'];
$third_sube				= $_POST['third_sube'];
$third_marke				= $_POST['third_marke'];
$third_tote				= $_POST['third_tote'];
$third_subf				= $_POST['third_subf'];
$third_markf				= $_POST['third_markf'];
$third_totf				= $_POST['third_totf'];
$third_subg				= $_POST['third_subg'];
$third_markg				= $_POST['third_markg'];
$third_totg				= $_POST['third_totg'];
$third_subh			= $_POST['third_subh'];
$third_markh			= $_POST['third_markh'];
$third_toth				= $_POST['third_toth'];
$third_subi				= $_POST['third_subi'];
$third_marki				= $_POST['third_marki'];
$third_toti				= $_POST['third_toti'];
$third_subj				= $_POST['third_subj'];
$third_markj				= $_POST['third_markj'];
$third_totj				= $_POST['third_totj'];

try
		{
		
			 $stmt = $pdo->prepare("INSERT INTO candidate_registration(regno,name,father_name,dob,session,course,mother_name,
			branch,address,percentage,mark_obtained,total_mark,result,subjecta,marka,total_marka,subjectb,markb,total_markb
			,subjectc,markc,total_markc,subjectd,markd,total_markd,subjecte,marke,total_marke,subjectf,markf,total_markf
			,subjectg,markg,total_markg,subjecth,markh,total_markh,subjecti,marki,total_marki
			,subjectj,markj,total_markj,subjectk,markk,total_markk,
			suba,markaa,tota,subb,markbb,totb,subc,markcc,totc,subd,markdd,totd,sube,markee,tote,subf,markff,totf,subg,markgg,totg,subh,markhh,toth,subi,markii,toti
			,subj,markjj,totj,subk,markkeleven,totk,
			third_suba,third_marka,third_tota,third_subb,third_markb,third_totb,third_subc,third_markc,third_totc,third_subd,third_markd,third_totd,third_sube,third_marke,third_tote,third_subf,third_markf,third_totf,third_subg,third_markg,third_totg,third_subh,third_markh,third_toth,third_subi,third_marki,third_toti
			,third_subj,third_markj,third_totj) 
			VALUES(:regno,:name,:father_name,:dob,:session,:course,:mother_name,:branch,:address,:percentage,:mark_obtained,:total_mark,:result,
			:subjecta,:marka,:total_marka,:subjectb,:markb,:total_markb,:subjectc,:markc,:total_markc
			,:subjectd,:markd,:total_markd,:subjecte,:marke,:total_marke,:subjectf,:markf,:total_markf
			,:subjectg,:markg,:total_markg,:subjecth,:markh,:total_markh,:subjecti,:marki,:total_marki
			,:subjectj,:markj,:total_markj,:subjectk,:markk,:total_markk,
			:suba,:markaa,:tota,:subb,:markbb,:totb,:subc,:markcc,:totc,:subd,:markdd,:totd,:sube,:markee,:tote,:subf,:markff,:totf,:subg,:markgg,:totg,:subh,:markhh,:toth,:subi,:markii,:toti
			,:subj,:markjj,:totj,:subk,:markkeleven,:totk,
			:third_suba,:third_marka,:third_tota,:third_subb,:third_markb,:third_totb,:third_subc,:third_markc,:third_totc,:third_subd,:third_markd,:third_totd,:third_sube,:third_marke,:third_tote,:third_subf,:third_markf,:third_totf,:third_subg,:third_markg,:third_totg,:third_subh,:third_markh,:third_toth,:third_subi,:third_marki,:third_toti
			,:third_subj,:third_markj,:third_totj
			)");
			$stmt->bindparam(":regno",$regno);
				$stmt->bindparam(":name",$name);
					$stmt->bindparam(":father_name",$father_name);
				$stmt->bindparam(":dob",$dob);
				$stmt->bindparam(":session",$session); 
					$stmt->bindparam(":course",$course);
					$stmt->bindparam(":mother_name",$mother_name); 
		$stmt->bindparam(":branch",$branch);
			$stmt->bindparam(":address",$address);
		$stmt->bindparam(":percentage",$percentage);
					$stmt->bindparam(":mark_obtained",$mark_obtained);
			$stmt->bindparam(":total_mark",$total_mark);
			$stmt->bindparam(":result",$result); 
			$stmt->bindparam(":subjecta",$subjecta);
			$stmt->bindparam(":marka",$marka);
			$stmt->bindparam(":total_marka",$total_marka);
			$stmt->bindparam(":subjectb",$subjectb);
			$stmt->bindparam(":markb",$markb);
			$stmt->bindparam(":total_markb",$total_markb);
			$stmt->bindparam(":subjectc",$subjectc);
			$stmt->bindparam(":markc",$markc);
			$stmt->bindparam(":total_markc",$total_markc);
			$stmt->bindparam(":subjectd",$subjectd);
			$stmt->bindparam(":markd",$markd);
			$stmt->bindparam(":total_markd",$total_markd);
			$stmt->bindparam(":subjecte",$subjecte);
			$stmt->bindparam(":marke",$marke);
			$stmt->bindparam(":total_marke",$total_marke);
			$stmt->bindparam(":subjectf",$subjectf);
			$stmt->bindparam(":markf",$markf);
			$stmt->bindparam(":total_markf",$total_markf);
			$stmt->bindparam(":subjectg",$subjectg);
			$stmt->bindparam(":markg",$markg);
			$stmt->bindparam(":total_markg",$total_markg);
			$stmt->bindparam(":subjecth",$subjecth);
			$stmt->bindparam(":markh",$markh);
			$stmt->bindparam(":total_markh",$total_markh);
			$stmt->bindparam(":subjecti",$subjecti);
			$stmt->bindparam(":marki",$marki);
			$stmt->bindparam(":total_marki",$total_marki);
			$stmt->bindparam(":subjectj",$subjectj);
			$stmt->bindparam(":markj",$markj);
			$stmt->bindparam(":total_markj",$total_markj);
			
			$stmt->bindparam(":subjectk",$subjectk);
			$stmt->bindparam(":markk",$markk);
			$stmt->bindparam(":total_markk",$total_markk);
			
			
			$stmt->bindparam(":suba",$suba);
			$stmt->bindparam(":markaa",$markaa);
			$stmt->bindparam(":tota",$tota);
			$stmt->bindparam(":subb",$subb);
			$stmt->bindparam(":markbb",$markbb);
			$stmt->bindparam(":totb",$totb);
			$stmt->bindparam(":subc",$subc);
			$stmt->bindparam(":markcc",$markcc);
			$stmt->bindparam(":totc",$totc);
			$stmt->bindparam(":subd",$subd);
			$stmt->bindparam(":markdd",$markdd);
			$stmt->bindparam(":totd",$totd);
			$stmt->bindparam(":sube",$sube);
			$stmt->bindparam(":markee",$markee);
			$stmt->bindparam(":tote",$tote);
			$stmt->bindparam(":subf",$subf);
			$stmt->bindparam(":markff",$markff);
			$stmt->bindparam(":totf",$totf);
			$stmt->bindparam(":subg",$subg);
			$stmt->bindparam(":markgg",$markgg);
			$stmt->bindparam(":totg",$totg);
			$stmt->bindparam(":subh",$subh);
			$stmt->bindparam(":markhh",$markhh);
			$stmt->bindparam(":toth",$toth);
			$stmt->bindparam(":subi",$subi);
			$stmt->bindparam(":markii",$markii);
			$stmt->bindparam(":toti",$toti);
			$stmt->bindparam(":subj",$subj);
			$stmt->bindparam(":markjj",$markjj);
			$stmt->bindparam(":totj",$totj);
			
			$stmt->bindparam(":subk",$subk);
			$stmt->bindparam(":markkeleven",$markkeleven);
			$stmt->bindparam(":totk",$totk);
			
			
			
			
			$stmt->bindparam(":third_suba",$third_suba);
			$stmt->bindparam(":third_marka",$third_marka);
			$stmt->bindparam(":third_tota",$third_tota);
			$stmt->bindparam(":third_subb",$third_subb);
			$stmt->bindparam(":third_markb",$third_markb);
			$stmt->bindparam(":third_totb",$third_totb);
			$stmt->bindparam(":third_subc",$third_subc);
			$stmt->bindparam(":third_markc",$third_markc);
			$stmt->bindparam(":third_totc",$third_totc);
			$stmt->bindparam(":third_subd",$third_subd);
			$stmt->bindparam(":third_markd",$third_markd);
			$stmt->bindparam(":third_totd",$third_totd);
			$stmt->bindparam(":third_sube",$third_sube);
			$stmt->bindparam(":third_marke",$third_marke);
			$stmt->bindparam(":third_tote",$third_tote);
			$stmt->bindparam(":third_subf",$third_subf);
			$stmt->bindparam(":third_markf",$third_markf);
			$stmt->bindparam(":third_totf",$third_totf);
			$stmt->bindparam(":third_subg",$third_subg);
			$stmt->bindparam(":third_markg",$third_markg);
			$stmt->bindparam(":third_totg",$third_totg);
			$stmt->bindparam(":third_subh",$third_subh);
			$stmt->bindparam(":third_markh",$third_markh);
			$stmt->bindparam(":third_toth",$third_toth);
			$stmt->bindparam(":third_subi",$third_subi);
			$stmt->bindparam(":third_marki",$third_marki);
			$stmt->bindparam(":third_toti",$third_toti);
			$stmt->bindparam(":third_subj",$third_subj);
			$stmt->bindparam(":third_markj",$third_markj);
			$stmt->bindparam(":third_totj",$third_totj);
			
				if($stmt->execute()){
				
echo "<script>alert('Candidate record Has been successfully insert')</script>";
	echo "<script>window.open('manage-candidate.php','_self')</script>";				
			 //header("Location:manage-candidate.php");
			}
			
			else{}
					
			
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

                     
                     
                     
                     
                     
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Insert Candidate</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Candidate
                        </div>
                        <div class="panel-body">
                            <form name="form"  method="post" enctype="multipart/form-data">
                               <div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
							   <div class="form-group">
                                            <label> Reg No</label>
                                            <input class="form-control" type="text" name="regno">
                                        
                                        </div>
                                        <div class="form-group">
                                            <label> Name</label>
                                            <input class="form-control" type="text" name="name">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Father's Name</label>
                                            <input class="form-control" type="text" name="father_name">
                                        
                                        </div>
										  </div>
										</div>
										
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>DOB</label>
                                            <input class="form-control" type="date" name="dob">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Session</label>
                                            <input class="form-control" type="text" name="session">
                                        
                                        </div>
										  </div>
										</div>
										
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Course</label>
                                            <input class="form-control" type="text" name="course">
                                           </div>
                                        </div>
										
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mother's Name</label>
                                            <input class="form-control" type="text" name="mother_name">
                                           </div>
                                        </div>
										
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Branch</label>
                                            <input class="form-control" type="text" name="branch">
                                           </div>
                                        </div>
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Address</label>
                                            <input class="form-control" type="text" name="address">
                                           </div>
                                        </div>
										
										
										 </div>
										 
										
										 
										
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Percentage</label>
                                            <input class="form-control" type="text" name="percentage">
                                           </div>
                                        </div>
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtained">
                                           </div>
                                        </div>
										 </div>
										 
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark </label>
                                            <input class="form-control" type="text" name="total_mark">
                                           </div>
                                        </div>
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Result </label>
                                            <input class="form-control" type="text" name="result">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<h4>First Year Result</h4>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="subjecta">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marka">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marka">
                                           </div>
                                        </div>
										</div>
										
										
										
										
										
										
										
										
										
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="subjectb">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markb">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markb">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="subjectc">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markc">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markc">
                                           </div>
                                        </div>
										</div>
                                      
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="subjectd">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markd">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markd">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="subjecte">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marke">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marke">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="subjectf">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markf">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markf">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="subjectg">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markg">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markg">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="subjecth">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markh">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markh">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject9</label>
                                            <input class="form-control" type="text" name="subjecti">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marki">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marki">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject10</label>
                                            <input class="form-control" type="text" name="subjectj">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markj">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markj">
                                           </div>
                                        </div>
										</div>
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject11</label>
                                            <input class="form-control" type="text" name="subjectk">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markk">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markk">
                                           </div>
                                        </div>
										</div>
										
						
										<!-- first year end form -->
										<div class="col-md-12 col-sm-12 col-xs-12">
										<h4>Second Year Result</h4>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="suba">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markaa">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="tota">
                                           </div>
                                        </div>
										</div>
										
						
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="subb">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markbb">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totb">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="subc">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markcc">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totc">
                                           </div>
                                        </div>
										</div>
                                      
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="subd">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markdd">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totd">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="sube">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markee">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="tote">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="subf">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markff">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totf">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="subg">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markgg">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totg">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="subh">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markhh">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="toth">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject9</label>
                                            <input class="form-control" type="text" name="subi">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markii">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="toti">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject10</label>
                                            <input class="form-control" type="text" name="subj">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markjj">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totj">
                                           </div>
                                        </div>
										</div>
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject11</label>
                                            <input class="form-control" type="text" name="subk">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markkeleven">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totk">
                                           </div>
                                        </div>
										</div>
							

<!-- end second year end form -->
										<div class="col-md-12 col-sm-12 col-xs-12">
										<h4>Third Year Result</h4>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject1</label>
                                            <input class="form-control" type="text" name="third_suba">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_marka">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_tota">
                                           </div>
                                        </div>
										</div>
										
						
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject2</label>
                                            <input class="form-control" type="text" name="third_subb">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markb">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totb">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject3</label>
                                            <input class="form-control" type="text" name="third_subc">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markc">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totc">
                                           </div>
                                        </div>
										</div>
                                      
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject4</label>
                                            <input class="form-control" type="text" name="third_subd">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markd">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totd">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject5</label>
                                            <input class="form-control" type="text" name="third_sube">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_marke">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_tote">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject6</label>
                                            <input class="form-control" type="text" name="third_subf">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markf">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totf">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject7</label>
                                            <input class="form-control" type="text" name="third_subg">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markg">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totg">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject8</label>
                                            <input class="form-control" type="text" name="third_subh">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markh">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_toth">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject9</label>
                                            <input class="form-control" type="text" name="third_subi">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_marki">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_toti">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject10</label>
                                            <input class="form-control" type="text" name="third_subj">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markj">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totj">
                                           </div>
                                        </div>
										</div>
										
										
										
										



							
										
						<!--third year result end -->				
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
										
						
										
										
										
										 </div>
                                 <div class="col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="btn btn-info text-center"  name="submit">Submit </button>
                                  </div>
                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>

</body>
</html>
