
<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	
	 $query=$pdo->prepare("delete from candidate_registration where id='$delete_id' ");
	
	if($query->execute()){
	
	echo "<script>alert('Post Has been Deleted')</script>";
	echo "<script>window.open('manage-candidate.php','_self')</script>";
	
	}
	



}




?>