<?php include("header.php");?>

<style>
table {
    border-collapse: separate;
	background-color: #FFFFFF;
    border-spacing: 0;
    width: 50%;
	color: #666666;
    text-shadow: 0 1px 0 #FFFFFF;
	border: 1px solid #CCCCCC;
	box-shadow: 0 5px 5px -5px rgba(0, 0, 0, 0.3);
	margin: 0 auto;
	font-family: arial;
	margin-top: 20px;
}
table thead tr th {
    background: none repeat scroll 0 0 #EEEEEE;
    color: #222222;
    padding: 10px 14px;
    text-align: left;
	border-top: 0 none;
	font-size: 12px;
}
table tbody tr td{
    background-color: #FFFFFF;
	font-size: 11px;
    text-align: left;
	padding: 10px 14px;
	border-top: 1px solid #DDDDDD;
}
#pagination {
	text-align: center;
	margin-top: 20px;
}
#pagination a {
	border: 1px solid #CCCCCC;
	padding: 5px 10px;
	font-family: arial;
	text-decoration: none;
	background: none repeat scroll 0 0 #EEEEEE;
	color: #222222;
}
#pagination a:hover {
	background-color: #FFFFFF;
}
a#active{
	background-color: #FFFFFF;
}
</style>
<?php include("sidebar.php");?>

        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage Banner Table</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-12">
                  <!--   Kitchen Sink -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                            
                            
                            
                            
                            
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                         <th>Edit</th>
                                             <th>Delete</th>
                                            <th>id</th>
                                             <th>image</th>
                                              <th>  Title</th>
                                           
                                            <th>Description</th>
                                           
                                        </tr>
                                    </thead>
                                      <tbody>
                                    
                                     <?php include('dbconfig.php');
			   $fetch=$pdo->prepare("select * from banner order by id desc");
			   $fetch->execute();
			   while($row= $fetch->fetch()){
			   
			   ?>
                                    
                                    
                                        <tr>
                                         <td><a href="banner-edit.php?id=<?php echo $row["id"];?>">Edit</a></td>
                                              <td><a href="banner-delete.php?id=<?php echo $row["id"];?>">Delete</a></td>
                                            <td><?php echo $row["id"];?></td>
                                      <td>   <img src="../banner/<?php echo $row['image'];?>" name="pdf_file"  width="50px" height="50px">
                                          </td>
                                            <td><?php echo $row["name"];?></td>   
                                            <td><?php echo $row["describtion"];?></td>
                                            
                                             
                                           
                                        </tr>
                                       
                                        
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                       
                            
                            
                     <!-- End  Kitchen Sink -->
                </div>
                
            </div>
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->
            
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
   <?php include("footer.php");?>


</body>
</html>
