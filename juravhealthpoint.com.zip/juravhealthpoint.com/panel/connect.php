<?php $cnn=mysql_connect("localhost","ncvtindia","ncvtindia@500");
						$db=mysql_select_db("ncvtindia",$cnn);?>