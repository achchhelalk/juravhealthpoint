 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                    <?php
                    
                    error_reporting(E_ALL);
ini_set('display_errors', 1);
                    
require 'dbconfig.php';					 $e=$_GET['id'];
					 
					  $query =  $pdo->prepare("SELECT * FROM training_center WHERE id='".$e."' ");

$query->execute();
$row = $query->fetch();
 if(isset($_POST['submit']))

{
    $vtp_code= $_POST['vtp_code'];
$vtp_name= $_POST['vtp_name'];

$center_head= $_POST['center_head'];
$contact_no= $_POST['contact_no'];
$email= $_POST['email'];
$address= $_POST['address'];
$valid_upto= $_POST['valid_upto'];
$sectora= $_POST['sectora'];
$sectorb= $_POST['sectorb'];
$sectorc= $_POST['sectorc'];
$sectord= $_POST['sectord'];
$sectore= $_POST['sectore'];
$sectorf= $_POST['sectorf'];
$sectorg= $_POST['sectorg'];
$sectorh= $_POST['sectorh'];
try
		{
		    
		  
		    
			$stmt = $pdo->prepare("update training_center  set vtp_code='".$vtp_code."' , vtp_name='".$vtp_name."' ,center_head='".$center_head."',
contact_no='".$contact_no."' ,email='".$email."',address='".$address."' ,valid_upto='".$valid_upto."',sectora='".$sectora."' ,sectorb='".$sectorb."'
,sectorc='".$sectorc."' ,sectord='".$sectord."',sectore='".$sectore."' ,sectorf='".$sectorf."',sectorg='".$sectorg."' ,sectorh='".$sectorh."'			WHERE id='".$_GET['id']."' ");
			
			
			if($stmt->execute()){
				
			echo "<script>alert('Training Center Has been updated')</script>";
	echo "<script>window.open('manage-training-center.php','_self')</script>";
				
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	?>
	
	
	


        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Course</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
               <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Training Center
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                            
                              <div class="form-group">
                                            <label> Vtp code</label>
                                            <input class="form-control" type="text" name="vtp_code" value="<?php echo $row['vtp_code'];?>">
                            
                                        <div class="form-group">
                                            <label> Vtp Name</label>
                                            <input class="form-control" type="text" name="vtp_name" value="<?php echo $row['vtp_name'];?>">
                                                                                  </div>
																				
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Center Head</label>
                                            <input class="form-control" type="text" name="center_head" value="<?php echo $row['center_head'];?>">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>	Contact no</label>
                                            <input class="form-control" type="text" name="contact_no" value="<?php echo $row['contact_no'];?>">
                                             </div>
                                        <div class="form-group">
                                            <label> Email</label>
                                            <input class="form-control" type="text" name="email" value="<?php echo $row['email'];?>">
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Address</label>
                                            <input class="form-control" type="text" name="address" value="<?php echo $row['address'];?>">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>	valid upto</label>
                                            <input class="form-control" type="text" name="valid_upto" value="<?php echo $row['valid_upto'];?>">
                                             </div>
											 <div class="form-group">
                                            <label>	sectora</label>
                                            <input class="form-control" type="text" name="sectora" value="<?php echo $row['sectora'];?>">
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Sectorb</label>
                                            <input class="form-control" type="text" name="sectorb" value="<?php echo $row['sectorb'];?>">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>Sectorc</label>
                                            <input class="form-control" type="text" name="sectorc" value="<?php echo $row['sectorc'];?>">
                                             </div>
											 <div class="form-group">
                                            <label> Sectord</label>
                                            <input class="form-control" type="text" name="sectord" value="<?php echo $row['sectord'];?>">
                                                                                  </div>
                                        <div class="form-group">
                                            <label>Sectore</label>
                                            <input class="form-control" type="text" name="sectore" value="<?php echo $row['sectore'];?>">
                                          
                                        </div>
					                   <div class="form-group">
                                            <label>sectorf</label>
                                            <input class="form-control" type="text" name="sectorf" value="<?php echo $row['sectorf'];?>">
                                             </div>
											  <div class="form-group">
                                            <label>sectorg</label>
                                            <input class="form-control" type="text" name="sectorg" value="<?php echo $row['sectorg'];?>">
                                             </div>
					<div class="form-group">
                                            <label>sectorh</label>
                                            <input class="form-control" type="text" name="sectorh" value="<?php echo $row['sectorh'];?>">
                                             </div>
					
                                                                                    
                                  
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>

</body>
</html>
