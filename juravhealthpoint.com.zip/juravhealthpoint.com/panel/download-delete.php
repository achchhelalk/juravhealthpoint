<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	$delete_query = $pdo->prepare("delete from download_pdf where id='$delete_id' ");
	
	if($delete_query->execute()){
	
	echo "<script>alert('download_pdf Has been Deleted')</script>";
	echo "<script>window.open('manage-download.php','_self')</script>";
		}
	



}




?>
