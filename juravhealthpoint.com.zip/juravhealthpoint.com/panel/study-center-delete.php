
<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	$delete_query = $pdo->prepare("delete from study_center where id='$delete_id' ");
	
	if($delete_query->execute()){
	
    echo "<script>alert('study center  Has been Deleted')</script>";
	echo "<script>window.open('manage-study-center.php','_self')</script>";
		}
	
}

?>


