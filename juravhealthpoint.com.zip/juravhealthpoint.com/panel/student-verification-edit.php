 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                    <?php
require 'dbconfig.php';					 $e=$_GET['id'];
					 
					  $query =  $pdo->prepare("SELECT * FROM student_enrolment WHERE id='$e' ");

$query->execute();
$row = $query->fetch();
 if(isset($_POST['submit']))

{
$enrollment_no= $_POST['enrollment_no'];
$name= $_POST['name'];
$father_name= $_POST['father_name'];

$course= $_POST['course'];
$centers_code= $_POST['centers_code'];
$session= $_POST['session'];
$result= $_POST['result'];

try
		{
			$stmt = $pdo->prepare("UPDATE student_enrolment  SET enrollment_no='".$enrollment_no."',name='".$name."' ,father_name='".$father_name."',course='".$course."' ,centers_code='".$centers_code."',session='".$session."',result='".$result."' WHERE id=".$_GET['id']." ");
			
			
			if($stmt->execute()){
				
			 echo "<script>alert('Student Verification Has been updated')</script>";
	echo "<script>window.open('manage-student-verification.php','_self')</script>";	
				
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	?>
	
	
	


        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Student Enrolment</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Edit Student Enrolment
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                            
                                       <div class="form-group">
                                            <label> Enrollment NO.</label>
                                            <input class="form-control" type="text" name="enrollment_no" value="<?php echo $row['enrollment_no'] ;?>" >
                                                                                  </div>
                                
                                        <div class="form-group">
                                            <label> Name</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo $row['name'] ;?>">
                                                                                  </div>
                                
                                        
                                         <div class="form-group">
                                            <label> Father</label>
                                            <input class="form-control" type="text" name="father_name" value="<?php echo $row['father_name'] ;?>">
                                                                                  </div>
																				  
											  <div class="form-group">
                                            <label> Course</label>
                                            <input class="form-control" type="text" name="course" value="<?php echo $row['course'] ;?>">
                                                                                  </div>									  
										  <div class="form-group">
                                            <label> Training Center</label>
                                            <input class="form-control" type="text" name="centers_code" value="<?php echo $row['centers_code'] ;?>">
                                                                                  </div>
																				   <div class="form-group" >
                                            <label> Session</label>
                                            <input class="form-control" type="text" name="session" value="<?php echo $row['session'] ;?>">
                                                                                  </div>
																				    <div class="form-group" >
                                            <label> Result/Grade</label>
                                            <input class="form-control" type="text" name="result" value="<?php echo $row['result'] ;?>">
                                                                                  </div>
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>

</body>
</html>
