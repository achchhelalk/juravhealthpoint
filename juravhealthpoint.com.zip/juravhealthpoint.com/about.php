<?php include("header.php"); ?>
<body>
<div class ="container">
  <div class="jumbotron" class="background-color:DodgerBlue"> 
  <h1>About Us</h1> 
  <p> JURAV HEALTH POINT is born of a dream.A dream that the people of India get the best healthcare at affordable prices. A dream that the best infrastructure and technology be provided to doctors so that they can serve patients to best of their capability. A dream that our people need not flee to metros for medical needs. This conviction inspired us to make a world class clinic in the heart of the country where the best infrastructure meets the best doctors to deliver cutting edge technology with care.

    JURAV HEALTH POINT is designed with india accredited clinic infrastructure norms.
  <p/>
  </div>
  <div class="row">
  
  <div class="col-sm-4" class ="container">
  <div class="jumbotron"  >
  <h3>Mission</h3>
  <p> Our mission is to provide the best quality medical service with utmost responsibility and compassion. Our management ensures that every patient gets the best possible honest treatment whether preventive or diagnostic.</p>
   </div>
   </div>
   
 <div class="col-sm-4" class ="container">
  <div class="jumbotron" >
  <h3>Vission</h3>
  <p> To achieve excellence in health care delivery system through hard work & human touch. </p>
   </div>
   </div>
  <div  class ="container">
  <div class="jumbotron" >
  <h4> We have 24-hour Emergency providing services. The treatment of acutely ill or injured patients is done by trained doctors and emergency well trained nurse practitioners.</h4>
  </div>
   </div>
  <div  class ="container">
  <div class="jumbotron" >
  <h5> We are committed to serve the communities by the highest quality patient care to them at affordable prices and Most Trusted facility at clinic</h5>
  </div>
   </div>
  </div>
</div>

</body
<?php include("footer.php"); ?>
  