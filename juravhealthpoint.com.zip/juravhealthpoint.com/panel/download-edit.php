 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                    <?php
require 'dbconfig.php';					 $e=$_GET['id'];
					 
					  $query =  $pdo->prepare("SELECT * FROM download_pdf WHERE id='$e' ");

$query->execute();
$row = $query->fetch();
 if(isset($_POST['submit']))

{
$name						= $_POST['name'];
$describtion 					= $_POST['describtion'];

try
		{
			$stmt = $pdo->prepare("UPDATE download_pdf  SET name='".$name."' ,describtion='".$describtion."' WHERE id=".$_GET['id']." ");
			
			
			if($stmt->execute()){
				
			 echo "<script>alert('Download Has been updated')</script>";
	echo "<script>window.open('manage-download.php','_self')</script>";	
				
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	?>
	
	<?php
 
if(!empty($_FILES['image']['name'])){
$image= $_FILES['image']['name'];
$image_tmp= $_FILES['image']['tmp_name'];
move_uploaded_file($image_tmp,"../download_pdf/$image");
try		{
			$stmt1 = $pdo->prepare("UPDATE   download_pdf SET 
			image='".$image."' WHERE id='".$_GET['id']."'  ");
						
											if($stmt1->execute())  
        {
			 //echo "<script>alert(' Your Record Successfully Updated')</script>";
	//echo "<script>window.open('my-cart.php','_self')</script>";
			
		}
				}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
  }
  
?> 

	


        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit download</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Edit Download
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                            
                                        <div class="form-group">
                                            <label>  Name</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo $row['name'];?>">
                                          
                                        </div>
                                        
                                        
					<div class="form-group">
                                            <label>Pdf File</label>
                                            <input class="form-control" type="file" name="image">
                                            
                                            
                         <img src="download_pdf/<?php echo $row['image'];?>" name="image"  width="50px" height="50px">
                                          
                                        </div>
                                        
                                        
                                        
                                        
                                
                                            <div class="form-group">
                                            <label>Describtion</label>
                                            <textarea class="form-control ckeditor" rows="3" name="describtion" value=""><?php echo $row['describtion'];?></textarea>
                                        </div>
                                  
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>

</body>
</html>
