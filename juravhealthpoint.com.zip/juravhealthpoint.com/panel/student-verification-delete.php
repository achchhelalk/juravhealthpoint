
<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	
	 $query=$pdo->prepare("delete from student_enrolment where id='$delete_id' ");
	
	if($query->execute()){
	
	echo "<script>alert('Student Verification Has been Deleted')</script>";
	echo "<script>window.open('manage-student-verification.php','_self')</script>";
	
	}
	
}

?>
