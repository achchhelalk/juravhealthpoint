 <?php 
 ini_set('display_errors', 1);
error_reporting(E_ALL ^ E_NOTICE);
  include("header.php");
 
 ?>

                     <?php include("sidebar.php");?>
                     
                     
                     <?php
require 'dbconfig.php';

$id=$_GET['id'];
$query=$pdo->prepare("select * from  admin_candidate_register where id='$id' ");
$query->execute();
$row=$query->fetch();

if(isset($_POST['submit']))
{
$rollno						= $_POST['rollno'];
$name						= $_POST['name'];
$session					= $_POST['session'];
$father_name					= $_POST['father_name'];
$dob					= $_POST['dob'];
$mode						= $_POST['mode'];
$course						= $_POST['course'];

$branch					= $_POST['branch'];
$year					= $_POST['year'];
$study_center					= $_POST['study_center'];


$subjecta						= $_POST['subjecta'];
$max_marka					= $_POST['max_marka'];
$mark_obtaineda					= $_POST['mark_obtaineda'];
$total_marka					= $_POST['total_marka'];

$subjectb						= $_POST['subjectb'];
$max_markb					= $_POST['max_markb'];
$mark_obtainedb					= $_POST['mark_obtainedb'];
$total_markb					= $_POST['total_markb'];

$subjectc						= $_POST['subjectc'];
$max_markc					= $_POST['max_markc'];
$mark_obtainedc					= $_POST['mark_obtainedc'];
$total_markc					= $_POST['total_markc'];


$subjectd						= $_POST['subjectd'];
$max_markd					= $_POST['max_markd'];
$mark_obtainedd					= $_POST['mark_obtainedd'];
$total_markd					= $_POST['total_markd'];


$subjecte						= $_POST['subjecte'];
$max_marke					= $_POST['max_marke'];
$mark_obtainede					= $_POST['mark_obtainede'];
$total_marke					= $_POST['total_marke'];

$subjectf						= $_POST['subjectf'];
$max_markf					= $_POST['max_markf'];
$mark_obtainedf					= $_POST['mark_obtainedf'];
$total_markf					= $_POST['total_markf'];


$subjectg						= $_POST['subjectg'];
$max_markg					= $_POST['max_markg'];
$mark_obtainedg					= $_POST['mark_obtainedg'];
$total_markg					= $_POST['total_markg'];


$subjecth						= $_POST['subjecth'];
$max_markh					= $_POST['max_markh'];
$mark_obtainedh					= $_POST['mark_obtainedh'];
$total_markh					= $_POST['total_markh'];
$percentage					= $_POST['percentage'];
$result					= $_POST['result'];





$second_year					= $_POST['second_year'];
$second_subjecta						= $_POST['second_subjecta'];
$second_max_marka					= $_POST['second_max_marka'];
$second_mark_obtaineda					= $_POST['second_mark_obtaineda'];
$second_total_marka					= $_POST['second_total_marka'];

$second_subjectb						= $_POST['second_subjectb'];
$second_max_markb					= $_POST['second_max_markb'];
$second_mark_obtainedb					= $_POST['second_mark_obtainedb'];
$second_total_markb					= $_POST['second_total_markb'];

$second_subjectc						= $_POST['second_subjectc'];
$second_max_markc					= $_POST['second_max_markc'];
$second_mark_obtainedc					= $_POST['second_mark_obtainedc'];
$second_total_markc					= $_POST['second_total_markc'];


$second_subjectd						= $_POST['second_subjectd'];
$second_max_markd					= $_POST['second_max_markd'];
$second_mark_obtainedd					= $_POST['second_mark_obtainedd'];
$second_total_markd					= $_POST['second_total_markd'];


$second_subjecte						= $_POST['second_subjecte'];
$second_max_marke					= $_POST['second_max_marke'];
$second_mark_obtainede					= $_POST['second_mark_obtainede'];
$second_total_marke					= $_POST['second_total_marke'];

$second_subjectf						= $_POST['second_subjectf'];
$second_max_markf					= $_POST['second_max_markf'];
$second_mark_obtainedf					= $_POST['second_mark_obtainedf'];
$second_total_markf					= $_POST['second_total_markf'];


$second_subjectg						= $_POST['second_subjectg'];
$second_max_markg					= $_POST['second_max_markg'];
$second_mark_obtainedg					= $_POST['second_mark_obtainedg'];
$second_total_markg					= $_POST['second_total_markg'];


$second_subjecth						= $_POST['second_subjecth'];
$second_max_markh					= $_POST['second_max_markh'];
$second_mark_obtainedh					= $_POST['second_mark_obtainedh'];
$second_total_markh					= $_POST['second_total_markh'];



$third_year					= $_POST['third_year'];
$third_subjecta						= $_POST['third_subjecta'];
$third_max_marka					= $_POST['third_max_marka'];
$third_mark_obtaineda					= $_POST['third_mark_obtaineda'];
$third_total_marka					= $_POST['third_total_marka'];

$third_subjectb						= $_POST['third_subjectb'];
$third_max_markb					= $_POST['third_max_markb'];
$third_mark_obtainedb					= $_POST['third_mark_obtainedb'];
$third_total_markb					= $_POST['third_total_markb'];

$third_subjectc						= $_POST['third_subjectc'];
$third_max_markc					= $_POST['third_max_markc'];
$third_mark_obtainedc					= $_POST['third_mark_obtainedc'];
$third_total_markc					= $_POST['third_total_markc'];


$third_subjectd						= $_POST['third_subjectd'];
$third_max_markd					= $_POST['third_max_markd'];
$third_mark_obtainedd					= $_POST['third_mark_obtainedd'];
$third_total_markd					= $_POST['third_total_markd'];


$third_subjecte						= $_POST['third_subjecte'];
$third_max_marke					= $_POST['third_max_marke'];
$third_mark_obtainede					= $_POST['third_mark_obtainede'];
$third_total_marke					= $_POST['third_total_marke'];

$third_subjectf						= $_POST['third_subjectf'];
$third_max_markf					= $_POST['third_max_markf'];
$third_mark_obtainedf					= $_POST['third_mark_obtainedf'];
$third_total_markf					= $_POST['third_total_markf'];


$third_subjectg						= $_POST['third_subjectg'];
$third_max_markg					= $_POST['third_max_markg'];
$third_mark_obtainedg					= $_POST['third_mark_obtainedg'];
$third_total_markg					= $_POST['third_total_markg'];


$third_subjecth						= $_POST['third_subjecth'];
$third_max_markh					= $_POST['third_max_markh'];
$third_mark_obtainedh					= $_POST['third_mark_obtainedh'];
$third_total_markh					= $_POST['third_total_markh'];


$third_year					= $_POST['third_year'];
$third_subjecta						= $_POST['third_subjecta'];
$third_max_marka					= $_POST['third_max_marka'];
$third_mark_obtaineda					= $_POST['third_mark_obtaineda'];
$third_total_marka					= $_POST['third_total_marka'];

$third_subjectb						= $_POST['third_subjectb'];
$third_max_markb					= $_POST['third_max_markb'];
$third_mark_obtainedb					= $_POST['third_mark_obtainedb'];
$third_total_markb					= $_POST['third_total_markb'];

$third_subjectc						= $_POST['third_subjectc'];
$third_max_markc					= $_POST['third_max_markc'];
$third_mark_obtainedc					= $_POST['third_mark_obtainedc'];
$third_total_markc					= $_POST['third_total_markc'];


$third_subjectd						= $_POST['third_subjectd'];
$third_max_markd					= $_POST['third_max_markd'];
$third_mark_obtainedd					= $_POST['third_mark_obtainedd'];
$third_total_markd					= $_POST['third_total_markd'];


$third_subjecte						= $_POST['third_subjecte'];
$third_max_marke					= $_POST['third_max_marke'];
$third_mark_obtainede					= $_POST['third_mark_obtainede'];
$third_total_marke					= $_POST['third_total_marke'];

$third_subjectf						= $_POST['third_subjectf'];
$third_max_markf					= $_POST['third_max_markf'];
$third_mark_obtainedf					= $_POST['third_mark_obtainedf'];
$third_total_markf					= $_POST['third_total_markf'];


$third_subjectg						= $_POST['third_subjectg'];
$third_max_markg					= $_POST['third_max_markg'];
$third_mark_obtainedg					= $_POST['third_mark_obtainedg'];
$third_total_markg					= $_POST['third_total_markg'];


$third_subjecth						= $_POST['third_subjecth'];
$third_max_markh					= $_POST['third_max_markh'];
$third_mark_obtainedh					= $_POST['third_mark_obtainedh'];
$third_total_markh					= $_POST['third_total_markh'];



$third_year					= $_POST['third_year'];
$third_subjecta						= $_POST['third_subjecta'];
$third_max_marka					= $_POST['third_max_marka'];
$third_mark_obtaineda					= $_POST['third_mark_obtaineda'];
$third_total_marka					= $_POST['third_total_marka'];

$third_subjectb						= $_POST['third_subjectb'];
$third_max_markb					= $_POST['third_max_markb'];
$third_mark_obtainedb					= $_POST['third_mark_obtainedb'];
$third_total_markb					= $_POST['third_total_markb'];

$third_subjectc						= $_POST['third_subjectc'];
$third_max_markc					= $_POST['third_max_markc'];
$third_mark_obtainedc					= $_POST['third_mark_obtainedc'];
$third_total_markc					= $_POST['third_total_markc'];


$third_subjectd						= $_POST['third_subjectd'];
$third_max_markd					= $_POST['third_max_markd'];
$third_mark_obtainedd					= $_POST['third_mark_obtainedd'];
$third_total_markd					= $_POST['third_total_markd'];


$third_subjecte						= $_POST['third_subjecte'];
$third_max_marke					= $_POST['third_max_marke'];
$third_mark_obtainede					= $_POST['third_mark_obtainede'];
$third_total_marke					= $_POST['third_total_marke'];

$third_subjectf						= $_POST['third_subjectf'];
$third_max_markf					= $_POST['third_max_markf'];
$third_mark_obtainedf					= $_POST['third_mark_obtainedf'];
$third_total_markf					= $_POST['third_total_markf'];


$third_subjectg						= $_POST['third_subjectg'];
$third_max_markg					= $_POST['third_max_markg'];
$third_mark_obtainedg					= $_POST['third_mark_obtainedg'];
$third_total_markg					= $_POST['third_total_markg'];


$third_subjecth						= $_POST['third_subjecth'];
$third_max_markh					= $_POST['third_max_markh'];
$third_mark_obtainedh					= $_POST['third_mark_obtainedh'];
$third_total_markh					= $_POST['third_total_markh'];





try
		{
					
			$stmt = $pdo->prepare("update admin_candidate_register SET 	rollno='".$rollno."' , name='".$name."' ,session='".$session."' ,father_name='".$father_name."' ,
			mode='".$mode."',dob='".$dob."' ,course='".$course."'  , branch='".$branch."'  , year='".$year."' ,
			name='".$name."' ,session='".$session."' ,father_name='".$father_name."' ,
			study_center='".$study_center."' ,
			subjecta='".$subjecta."'  , max_marka='".$max_marka."'  ,mark_obtaineda='".$mark_obtaineda."'  , total_marka='".$total_marka."',
			
		  subjectb='".$subjectb."'  , max_markb='".$max_markb."'  ,mark_obtainedb='".$mark_obtainedb."'  , total_markb='".$total_markb."',
		  subjectc='".$subjectc."'  , max_markc='".$max_markc."'  ,mark_obtainedc='".$mark_obtainedc."'  , total_markc='".$total_markc."',
		  subjectd='".$subjectd."'  , max_markd='".$max_markd."'  ,mark_obtainedd='".$mark_obtainedd."'  , total_markd='".$total_markd."',
		  subjecte='".$subjecte."'  , max_marke='".$max_marke."'  ,mark_obtainede='".$mark_obtainede."'  , total_marke='".$total_marke."',
		  subjectf='".$subjectf."'  , max_markf='".$max_markf."'  ,mark_obtainedf='".$mark_obtainedf."'  , total_markf='".$total_markf."',
		  subjectg='".$subjectg."'  , max_markg='".$max_markg."'  ,mark_obtainedg='".$mark_obtainedg."'  , total_markg='".$total_markg."',
		  subjecth='".$subjecth."'  , max_markh='".$max_markh."'  ,mark_obtainedh='".$mark_obtainedh."'  , total_markh='".$total_markh."',
		  percentage='".$percentage."'  , result='".$result."',
		  second_year='".$second_year."',
		  second_subjecta='".$second_subjecta."'  , second_max_marka='".$second_max_marka."'  ,second_mark_obtaineda='".$second_mark_obtaineda."'  , second_total_marka='".$second_total_marka."',
			
		  second_subjectb='".$second_subjectb."'  , second_max_markb='".$second_max_markb."'  ,second_mark_obtainedb='".$second_mark_obtainedb."'  , second_total_markb='".$second_total_markb."',
		  second_subjectc='".$second_subjectc."'  , second_max_markc='".$second_max_markc."'  ,second_mark_obtainedc='".$second_mark_obtainedc."'  , second_total_markc='".$second_total_markc."',
		  second_subjectd='".$second_subjectd."'  , second_max_markd='".$second_max_markd."'  ,second_mark_obtainedd='".$second_mark_obtainedd."'  , second_total_markd='".$second_total_markd."',
		  second_subjecte='".$second_subjecte."'  , second_max_marke='".$second_max_marke."'  ,second_mark_obtainede='".$second_mark_obtainede."'  , second_total_marke='".$second_total_marke."',
		  second_subjectf='".$second_subjectf."'  , second_max_markf='".$second_max_markf."'  ,second_mark_obtainedf='".$second_mark_obtainedf."'  , second_total_markf='".$second_total_markf."',
		  second_subjectg='".$second_subjectg."'  , second_max_markg='".$second_max_markg."'  ,second_mark_obtainedg='".$second_mark_obtainedg."'  , second_total_markg='".$second_total_markg."',
		  second_subjecth='".$second_subjecth."'  , second_max_markh='".$second_max_markh."'  ,second_mark_obtainedh='".$second_mark_obtainedh."'  , second_total_markh='".$second_total_markh."',
		  
		  third_year='".$third_year."',
		  third_subjecta='".$third_subjecta."'  , third_max_marka='".$third_max_marka."'  ,third_mark_obtaineda='".$third_mark_obtaineda."'  , third_total_marka='".$third_total_marka."',
			
		  third_subjectb='".$third_subjectb."'  , third_max_markb='".$third_max_markb."'  ,third_mark_obtainedb='".$third_mark_obtainedb."'  , third_total_markb='".$third_total_markb."',
		  third_subjectc='".$third_subjectc."'  , third_max_markc='".$third_max_markc."'  ,third_mark_obtainedc='".$third_mark_obtainedc."'  , third_total_markc='".$third_total_markc."',
		  third_subjectd='".$third_subjectd."'  , third_max_markd='".$third_max_markd."'  ,third_mark_obtainedd='".$third_mark_obtainedd."'  , third_total_markd='".$third_total_markd."',
		  third_subjecte='".$third_subjecte."'  , third_max_marke='".$third_max_marke."'  ,third_mark_obtainede='".$third_mark_obtainede."'  , third_total_marke='".$third_total_marke."',
		  third_subjectf='".$third_subjectf."'  , third_max_markf='".$third_max_markf."'  ,third_mark_obtainedf='".$third_mark_obtainedf."'  , third_total_markf='".$third_total_markf."',
		  third_subjectg='".$third_subjectg."'  , third_max_markg='".$third_max_markg."'  ,third_mark_obtainedg='".$third_mark_obtainedg."'  , third_total_markg='".$third_total_markg."',
		  third_subjecth='".$third_subjecth."'  , third_max_markh='".$third_max_markh."'  ,third_mark_obtainedh='".$third_mark_obtainedh."'  , third_total_markh='".$third_total_markh."'


			


			WHERE id=".$_GET['id']." ");
			//move_uploaded_file($rollno_tmp,"../rollnos/$rollno");
				//move_uploaded_file($brochure_tmp,"../rollnos/$brochure");
		
			if($stmt->execute()){
			
			
			echo "<script>alert('Candidate record Has been successfully Updated')</script>";
	echo "<script>window.open('manage-candidate.php','_self')</script>";
			}
						else{}
						
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

                     
                     
                     
                     
                     
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Candidate</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Edit Candidate
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                               <div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
							   
							   
							   <div class="form-group">
                                            <label> Roll no</label>
                                            <input class="form-control" type="text" name="rollno" value="<?php echo $row['rollno'];?>">
                                        
                                        </div>
							   
                                        <div class="form-group">
                                            <label> Name</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo $row['name'];?>">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Session</label>
                                            <input class="form-control" type="text" name="session" value="<?php echo $row['session'];?>">
                                        
                                        </div>
										  </div>
										</div>
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Father Name</label>
                                            <input class="form-control" type="text" name="father_name" value="<?php echo $row['father_name'];?>">
                                           </div>
                                        </div>
										 </div>
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>DOB</label>
                                            <input class="form-control" type="date" name="dob" value="<?php echo $row['dob'];?>">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Mode</label>
                                            <input class="form-control" type="text" name="mode" value="<?php echo $row['mode'];?>">
                                        
                                        </div>
										  </div>
										</div>
										
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Course</label>
                                            <input class="form-control" type="text" name="course" value="<?php echo $row['course'];?>">
                                           </div>
                                        </div>
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Branch</label>
                                            <input class="form-control" type="text" name="branch" value="<?php echo $row['branch'];?>">
                                           </div>
                                        </div>
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Year</label>
                                            <input class="form-control" type="text" name="year" value="<?php echo $row['year'];?>">
                                           </div>
                                        </div>
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Study Center</label>
                                            <input class="form-control" type="text" name="study_center" value="<?php echo $row['study_center'];?>">
                                           </div>
                                        </div>
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="subjecta" value="<?php echo $row['subjecta'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_marka" value="<?php echo $row['max_marka'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtaineda" value="<?php echo $row['mark_obtaineda'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label> Total Mark</label>
                                            <input class="form-control" type="text" name="total_marka" value="<?php echo $row['total_marka'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="subjectb" value="<?php echo $row['subjectb'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_markb" value="<?php echo $row['max_markb'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtainedb" value="<?php echo $row['mark_obtainedb'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="total_markb" value="<?php echo $row['total_markb'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="subjectc" value="<?php echo $row['subjectc'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_markc" value="<?php echo $row['max_markc'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtainedc" value="<?php echo $row['mark_obtainedc'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="total_markc" value="<?php echo $row['total_markc'];?>">
                                           </div>
                                        </div>
										
										 </div> 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="subjectd" value="<?php echo $row['subjectd'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_markd" value="<?php echo $row['max_markd'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtainedd" value="<?php echo $row['mark_obtainedd'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="total_markd" value="<?php echo $row['total_markd'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="subjecte" value="<?php echo $row['subjecte'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_marke"  value="<?php echo $row['max_marke'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtainede" value="<?php echo $row['mark_obtainede'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="total_marke" value="<?php echo $row['total_marke'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="subjectf" value="<?php echo $row['subjectf'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_markf" value="<?php echo $row['max_markf'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtainedf" value="<?php echo $row['mark_obtainedf'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="total_markf" value="<?php echo $row['total_markf'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="subjectg" value="<?php echo $row['subjectg'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_markg" value="<?php echo $row['max_markg'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtainedg" value="<?php echo $row['mark_obtainedg'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="total_markg" value="<?php echo $row['total_markg'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="subjecth" value="<?php echo $row['subjecth'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="max_markh" value="<?php echo $row['max_markh'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtainedh" value="<?php echo $row['mark_obtainedh'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="total_markh" value="<?php echo $row['total_markh'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										 
										 <a class="btn btn-primary secondry" >Second Year</a>
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12 secondry_save" style="display: none;">
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Second Year</label>
                                            <input class="form-control" type="text" name="second_year" value="<?php echo $row['second_year'];?>">
                                           </div>
                                        </div>
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="second_subjecta" value="<?php echo $row['second_subjecta'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_marka" value="<?php echo $row['second_max_marka'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtaineda" value="<?php echo $row['second_mark_obtaineda'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label> Total Mark</label>
                                            <input class="form-control" type="text" name="second_total_marka" value="<?php echo $row['second_total_marka'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="second_subjectb" value="<?php echo $row['second_subjectb'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_markb" value="<?php echo $row['second_max_markb'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtainedb" value="<?php echo $row['second_mark_obtaineb'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="second_total_markb" value="<?php echo $row['second_total_markb'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="second_subjectc" value="<?php echo $row['second_subjectc'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_markc" value="<?php echo $row['second_max_markc'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtainedc" value="<?php echo $row['second_mark_obtainedc'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="second_total_markc" value="<?php echo $row['second_total_markc'];?>">
                                           </div>
                                        </div>
										
										 </div> 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="second_subjectd" value="<?php echo $row['second_subjectd'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_markd" value="<?php echo $row['second_max_markd'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtainedd" value="<?php echo $row['second_mark_obtainedd'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="second_total_markd" value="<?php echo $row['second_total_markd'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="second_subjecte" value="<?php echo $row['second_subjecte'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_marke"  value="<?php echo $row['second_max_marke'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtainede"  value="<?php echo $row['second_mark_obtainede'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="second_total_marke" value="<?php echo $row['second_total_marke'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="second_subjectf" value="<?php echo $row['second_subjectf'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_markf" value="<?php echo $row['second_max_markf'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtainedf" value="<?php echo $row['second_mark_obtainedf'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="second_total_markf" value="<?php echo $row['second_total_markf'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="second_subjectg" value="<?php echo $row['second_subjectg'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_markg" value="<?php echo $row['second_max_markg'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtainedg" value="<?php echo $row['second_mark_obtainedg'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="second_total_markg" value="<?php echo $row['second_total_markg'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="second_subjecth" value="<?php echo $row['second_subjecth'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="second_max_markh" value="<?php echo $row['second_max_markh'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="second_mark_obtainedh" value="<?php echo $row['second_mark_obtainedh'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="second_total_markh" value="<?php echo $row['second_total_markh'];?>">
                                           </div>
                                        </div>
										
										 </div>
										  </div>
										 
										 
										 
										<div class="col-md-12 col-sm-12 col-xs-12">
										 
										 <a class="btn btn-primary third" >Third Year</a>
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12 third_save" style="display: none;">
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Third Year</label>
                                            <input class="form-control" type="text" name="third_year" value="<?php echo $row['third_year'];?>">
                                           </div>
                                        </div>
										 </div>
										 
										 
										 
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="third_subjecta" value="<?php echo $row['third_subjecta'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_marka" value="<?php echo $row['third_max_marka'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtaineda" value="<?php echo $row['third_mark_obtaineda'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label> Total Mark</label>
                                            <input class="form-control" type="text" name="third_total_marka" value="<?php echo $row['third_total_marka'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="third_subjectb" value="<?php echo $row['third_subjectb'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_markb" value="<?php echo $row['third_max_markb'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtainedb" value="<?php echo $row['third_mark_obtainedb'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="third_total_markb" value="<?php echo $row['third_total_markb'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="third_subjectc" value="<?php echo $row['third_subjectc'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_markc" value="<?php echo $row['third_max_markc'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtainedc"  value="<?php echo $row['third_mark_obtainedc'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="third_total_markc"  value="<?php echo $row['third_total_markc'];?>">
                                           </div>
                                        </div>
										
										 </div> 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="third_subjectd" value="<?php echo $row['third_subjectd'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_markd"  value="<?php echo $row['third_max_markd'];?>">
                                           </div>
                                        </div>
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtainedd"  value="<?php echo $row['third_mark_obtainedd'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="third_total_markd" value="<?php echo $row['third_total_markd'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="third_subjecte" value="<?php echo $row['third_subjecte'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_marke" value="<?php echo $row['third_max_marke'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtainede" value="<?php echo $row['third_mark_obtainede'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="third_total_marke" value="<?php echo $row['third_total_marke'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="third_subjectf" value="<?php echo $row['third_subjectf'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_markf" value="<?php echo $row['third_max_markf'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtainedf" value="<?php echo $row['third_mark_obtainedf'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="third_total_markf" value="<?php echo $row['third_total_markf'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="third_subjectg" value="<?php echo $row['third_subjectg'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_markg" value="<?php echo $row['third_max_markg'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtainedg" value="<?php echo $row['third_mark_obtainedg'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="third_total_markg" value="<?php echo $row['third_total_markg'];?>">
                                           </div>
                                        </div>
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="third_subjecth" value="<?php echo $row['third_subjecth'];?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Max Mark</label>
                                            <input class="form-control" type="text" name="third_max_markh" value="<?php echo $row['third_max_markh'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="third_mark_obtainedh" value="<?php echo $row['third_mark_obtainedh'];?>">
                                           </div>
                                        </div>
										
										<div class="col-md-3 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total mark</label>
                                            <input class="form-control" type="text" name="third_total_markh" value="<?php echo $row['third_total_markh'];?>">
                                           </div>
                                        </div>
										
										 </div>
										  </div> 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Percentage</label>
                                            <input class="form-control" type="text" name="percentage" value="<?php echo $row['percentage'];?>">
                                           </div>
                                        </div>
										 </div>
										 
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Result</label>
                                            <input class="form-control" type="text" name="result" value="<?php echo $row['result'];?>">
                                           </div>
                                        </div>
										 </div>
                                 <div class="col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="btn btn-info text-center"  name="submit">Submit </button>
                                  </div>
                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>
	
<script type="text/javascript">

 $(document).ready(function() {
        $('.secondry').click(function() {
                $('.secondry_save').toggle("slide");
        });
    });
</script>
<script type="text/javascript">

 $(document).ready(function() {
        $('.third').click(function() {
                $('.third_save').toggle("slide");
        });
    });



</script>



</body>
</html>
