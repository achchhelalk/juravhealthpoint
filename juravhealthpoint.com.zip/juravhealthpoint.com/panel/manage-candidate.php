<?php include("header.php");?>
<style>
table {
    border-collapse: separate;
	background-color: #FFFFFF;
    border-spacing: 0;
    width: 50%;
	color: #666666;
    text-shadow: 0 1px 0 #FFFFFF;
	border: 1px solid #CCCCCC;
	box-shadow: 0 5px 5px -5px rgba(0, 0, 0, 0.3);
	margin: 0 auto;
	font-family: arial;
	margin-top: 20px;
}
table thead tr th {
    background: none repeat scroll 0 0 #EEEEEE;
    color: #222222;
    padding: 10px 14px;
    text-align: left;
	border-top: 0 none;
	font-size: 12px;
}
table tbody tr td{
    background-color: #FFFFFF;
	font-size: 11px;
    text-align: left;
	padding: 10px 14px;
	border-top: 1px solid #DDDDDD;
}
#pagination {
	text-align: center;
	margin-top: 20px;
}
#pagination a {
	border: 1px solid #CCCCCC;
	padding: 5px 10px;
	font-family: arial;
	text-decoration: none;
	background: none repeat scroll 0 0 #EEEEEE;
	color: #222222;
}
#pagination a:hover {
	background-color: #FFFFFF;
}
a#active{
	background-color: #FFFFFF;
}
</style>

<?php include("sidebar.php");?>

        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage Candidate</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
              
            <div class="row">
                <div class="col-md-12">
                  <!--   Kitchen Sink -->
                    
                            <div class="table-responsive">
                            
                            
                            
                            
                            
                                <table id="example" style="width:100%" class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                             <th>Action</th>
                                              <th>Result</th>
                                            <th>Name</th>
                                            <th>Father Name</th>
                                             <th>RegNo</th>
                                               <th>Mother Name</th>
											  <th>Course</th>
											  <th>Session</th>
											  <th>Address</th>
											  <th>Percentage</th>
											  <th>Dob</th>
											  <th>Mark Obtained</th>
											  <th>Total Mark</th>
											  
											  
											 <th>Subject1</th>
											 <th>mark1</th>
											  <th>Subject2</th>
											  <th>mark2</th>
											  <th>Subject3</th>
											  <th>mark3</th>
											  <th>Subject4</th>
											  <th>mark4</th>
											  <th>Subject5</th>
											  <th>mark5</th>
											  <th>Subject6</th>
											  <th>mark6</th>
											  <th>Subject7</th>
											  <th>mark7</th>
											  <th>Subject8</th>
											  <th>mark8</th>
											  <th>Subject9</th>
											  <th>mark9</th>
											  <th>Subject10</th>
											  <th>mark10</th>
										
                                             
                                        </tr>
                                    </thead>
                                      <tbody>
									  <?php 
									  include('dbconfig.php');
									  $query=$pdo->prepare("select * from candidate_registration order by id desc");
									  $query->execute();
									  while($row= $query->fetch()){
									  
									  ?>
                                    <tr>
									 <td>
											  <a href="candidate-delete.php?id=<?php echo $row["id"];?>">Delete</a>&nbsp;
											  <a href="candidate-edit.php?id=<?php echo $row["id"];?>">Edit</a></td>
									 <td><?php echo $row["result"];?></td>
                                         <td><?php echo $row["name"];?></td>
										 <td><?php echo $row["father_name"];?></td>
										 <td><?php echo $row["regno"];?></td>
										 <td><?php echo $row["mother_name"];?></td>
										 <td><?php echo $row["course"];?></td>
										 <td><?php echo $row["session"];?></td>
										 <td><?php echo $row["address"];?></td>
										 <td><?php echo $row["percentage"];?></td>
										 <td><?php echo $row["dob"];?></td>
										  <td><?php echo $row["mark_obtained"];?></td>
										   <td><?php echo $row["total_mark"];?></td>
										   
										   <td><?php echo $row["subjecta"];?></td>
										   <td><?php echo $row["marka"];?></td>
										 <td><?php echo $row["subjectb"];?></td>
										 <td><?php echo $row["markb"];?></td>
										 <td><?php echo $row["subjectc"];?></td>
										 <td><?php echo $row["markc"];?></td>
										 <td><?php echo $row["subjectd"];?></td>
										 <td><?php echo $row["markd"];?></td>
										 <td><?php echo $row["subjecte"];?></td>
										 <td><?php echo $row["marke"];?></td>
										 <td><?php echo $row["subjectf"];?></td>
										 <td><?php echo $row["markf"];?></td>
										 <td><?php echo $row["subjectg"];?></td>
										 <td><?php echo $row["markg"];?></td>
										 <td><?php echo $row["subjecth"];?></td>
										 <td><?php echo $row["markh"];?></td>
										  <td><?php echo $row["subjecti"];?></td>
										  <td><?php echo $row["marki"];?></td>
										   <td><?php echo $row["subjectj"];?></td>
										   <td><?php echo $row["markj"];?></td>
										 
										
										
                                             
                                            
                                           
                                        </tr>
										
									  <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    
                
            </div>
              

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

  
<?php include('filter-footer.php');?>
