                          <!--<li>
                        <a class="active-menu" href="dashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="category-Insert.php"><i class="fa fa-desktop "></i>Category<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="category-insert.php"><i class="fa fa-toggle-on"></i>Category Insert</a>
                            </li>
                            <li>
                                <a href="manage-category.php"><i class="fa fa-code "></i>Manage Category</a>
                            </li>
                             <li>
                                <a href="category-edit.php"><i class="fa fa-edit "></i>Edit Category</a>
                            </li>
                           
                           
                        </ul>
                    </li>
					
					
                     <li>
                        <a href="category-Insert.php"><i class="fa fa-desktop "></i>Sub Category<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="sub-category-insert.php"><i class="fa fa-toggle-on"></i>Sub Category Insert</a>
                            </li>
                            <li>
                                <a href="manage-sub-category.php"><i class="fa fa-code "></i> Sub Manage Category</a>
                            </li>
                             <li>
                                <a href="sub-category-edit.php"><i class="fa fa-edit "></i> Sub Edit Category</a>
                            </li>
                           
                           
                        </ul>
                    </li>-->
					
					 <!--<li>
                        <a href=""><i class="fa fa-desktop "></i> Page<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="page-insert.php"><i class="fa fa-toggle-on"></i>  page Insert</a>
                            </li>
                            <li>
                                <a href="manage-page.php"><i class="fa fa-code "></i> Manage Page </a>
                            </li>
                             <li>
                                <a href="page-edit.php"><i class="fa fa-edit "></i> Edit Page</a>
                            </li>
                                             
                        </ul>
                    </li>


					 <li>
                        <a href="location-Insert.php"><i class="fa fa-desktop "></i>Menu Page<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="menu-page-insert.php"><i class="fa fa-toggle-on"></i> Menu page Insert</a>
                            </li>
                            <li>
                                <a href="manage-menu-page.php"><i class="fa fa-code "></i>Manage Menu Page </a>
                            </li>
                             <li>
                                <a href="menu-page-edit.php"><i class="fa fa-edit "></i>Edit Menu Page</a>
                            </li>
                                             
                        </ul>
                    </li>
					
                       <li>
                        <a href="#"><i class="fa fa-yelp "></i>Product  <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="product-insert.php"><i class="fa fa-coffee"></i>Insert Product</a>
                            </li>
                            <li>
                                <a href="manage-products.php"><i class="fa fa-flash "></i>Manage Product</a>
                            </li>
                             <li>
                                <a href="product-edit.php"><i class="fa fa-key "></i>Edit Product</a>
                            </li>
                                            
                        </ul>
                    </li>-->
					 
					
				<li>
                        <a href="#"><i class="fa fa-yelp "></i>Banner <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="banner-insert.php"><i class="fa fa-coffee"></i>Insert Banner</a>
                            </li>
                            <li>
                                <a href="manage-banner.php"><i class="fa fa-flash "></i>Manage Banner</a>
                            </li>
                                                                    
                        </ul>
                    </li>	
                    <li>
                        <a href="#"><i class="fa fa-yelp "></i>Lab Test <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="labtest-insert.php"><i class="fa fa-coffee"></i>Insert Lab Test</a>
                            </li>
                            <li>
                                <a href="manage-labtest.php"><i class="fa fa-flash "></i>Manage Lab Test</a>
                            </li>
                                                                    
                        </ul>
                    </li>	
                      <li>
                        <a href="#"><i class="fa fa-yelp "></i>Camp Testing <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="camp-testing-insert.php"><i class="fa fa-coffee"></i>Insert Camp Testing</a>
                            </li>
                            <li>
                                <a href="manage-camp-testing.php"><i class="fa fa-flash "></i>Manage Camp Testing</a>
                            </li>
                                                                    
                        </ul>
                    </li>	
                    	<!--<li>
                        <a href="#"><i class="fa fa-yelp "></i>Enrollment <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="enrolment-insert.php"><i class="fa fa-coffee"></i>Insert Enrollment </a>
                            </li>
                            <li>
                                <a href="manage-enrollment.php"><i class="fa fa-flash "></i>Manage Enrollment </a>
                            </li>
                                                                    
                        </ul>
                    </li>	
						<li>
                        <a href="#"><i class="fa fa-yelp "></i>Student Verification<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="student-verification-insert.php"><i class="fa fa-coffee"></i>Insert Student Verification </a>
                            </li>
                            <li>
                                <a href="manage-student-verification.php"><i class="fa fa-flash "></i>Manage Student Verification </a>
                            </li>
                                                                    
                        </ul>
                    </li>	
					  <li>
                                <a href="manage-franchisee.php"><i class="fa fa-coffee"></i>Manage Franchise </a>
                            </li>
					 <li>
                        <a href="#"><i class="fa fa-yelp "></i>Course <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="course-insert.php"><i class="fa fa-coffee"></i>Insert Course</a>
                            </li>
                            <li>
                                <a href="manage-course.php"><i class="fa fa-flash "></i>Manage Course</a>
                            </li>
                                                                    
                        </ul>
                    </li>
		    <li>
                        <a href="#"><i class="fa fa-yelp "></i>Download pdf <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="download-insert.php"><i class="fa fa-coffee"></i>Insert Download pdf</a>
                            </li>
                            <li>
                                <a href="manage-download.php"><i class="fa fa-flash "></i>Manage Download pdf</a>
                            </li>
                                                                    
                        </ul>
                    </li>
		    <li>
                        <a href="#"><i class="fa fa-yelp "></i>Study Center <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="study-center-insert.php"><i class="fa fa-coffee"></i>Insert Study Center</a>
                            </li>
                            <li>
                                <a href="manage-study-center.php"><i class="fa fa-flash "></i>Manage Study Center</a>
                            </li>
                                                                    
                        </ul>
                    </li>
		    
		    <li>
                        <a href="#"><i class="fa fa-yelp "></i>Student Zone <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="student-zone-insert.php"><i class="fa fa-coffee"></i>Insert Student Zone</a>
                            </li>
                            <li>
                                <a href="manage-student-zone.php"><i class="fa fa-flash "></i>Manage Student Zone</a>
                            </li>
                                                                    
                        </ul>
                    </li>
		    
		    
		    
		    
		    
		    
		    
		    
					
                     <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Candidate Registeration <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                                 <li>
                                <a href="candidate-insert.php"><i class="fa fa-desktop "></i>Insert Candidate Registeration  </a>
                            </li>
                             <li>
                                <a href="manage-candidate.php"><i class="fa fa-code "></i>Manage Candidate Registeration</a>
                            </li>
                                           
                        </ul>
                    </li>
		    <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Notice Board<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                                 <li>
                                <a href="notice-insert.php"><i class="fa fa-desktop "></i>Insert Notice Board  </a>
                            </li>
                             <li>
                                <a href="manage-notice.php"><i class="fa fa-code "></i>Manage Notice Board</a>
                            </li>
                                           
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Student Notice Board<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                                 <li>
                                <a href="student-notice-insert.php"><i class="fa fa-desktop "></i>Insert Student Notice Board  </a>
                            </li>
                             <li>
                                <a href="manage-student-notice.php"><i class="fa fa-code "></i>Manage Student Notice Board</a>
                            </li>
                                           
                        </ul>
                    </li>
                    	<li>
                        <a href="#"><i class="fa fa-yelp "></i>Training Center<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="training-center-insert.php"><i class="fa fa-coffee"></i>Insert Training Center</a>
                            </li>
                            <li>
                                <a href="manage-training-center.php"><i class="fa fa-flash "></i>Manage Training Center</a>
                            </li>
                                                                    
                        </ul>
                    </li>	
                      <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Contact Us Record <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                                                  
                             <li>
                                <a href="contactus-insert.php"><i class="fa fa-code "></i>Insert Contact Us</a>
                            </li>
			    <li>
                                <a href="manage-contactus.php"><i class="fa fa-code "></i>Manage Contact Us</a>
                            </li>
                             
                             
                           
                        </ul>
                    </li>
                    
                    
                      <!--<li>
                        <a href="gallery.html"><i class="fa fa-anchor "></i>Gallery</a>
                    </li>
                     <li>
                        <a href="error.html"><i class="fa fa-bug "></i>Error Page</a>
                    </li>
                    <li>
                        <a href="login.html"><i class="fa fa-sign-in "></i>Login Page</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Multilevel Link <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="#"><i class="fa fa-bicycle "></i>Second Level Link</a>
                            </li>
                             <li>
                                <a href="#"><i class="fa fa-flask "></i>Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link<span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li>
                                        <a href="#"><i class="fa fa-plus "></i>Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="fa fa-comments-o "></i>Third Level Link</a>
                                    </li>

                                </ul>

                            </li>
                        </ul>
                    </li>
                   
                    <li>
                        <a href="blank.html"><i class="fa fa-square-o "></i>Blank Page</a>
                    </li>-->
                </ul>

            </div>

        </nav>