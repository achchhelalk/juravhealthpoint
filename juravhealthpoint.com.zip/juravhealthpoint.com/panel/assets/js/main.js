var category_name = "";
var checkname = function(){
     var category_name = $("#category_name").val();
     $('#checking').html("");
	 if(category_name!=""){
	 	$('#checking').html("<p>Checking....</p>");
	 	$.ajax({
	      url: "checkcategory.php",
	      type: 'GET',
	      data: {category_name : category_name},
	      success: function(data) {  
	      	$('#checking').html("");
			if(data=="Available"){
				
				$('#checking').html('<p class="bg-success">Category is not  Exist Please Insert</p>');
			}else{
				
				$('#checking').html('<p class="bg-danger">Category Already Exist</p>');
			}
	  },
	  	  error: function(e) {
		 		$('#checking').html('<p class="bg-danger">There was an error</p>');
		}
	});

 }
}

