<?php
ob_start();
include("dbconfig.php");

 session_start();
 
 $query =  $pdo->prepare("SELECT * FROM register WHERE email=:email AND password=:password");
$query->bindParam(':email', $_POST['email']);
$query->bindParam(':password', $_POST['password']);
$query->execute();

if($row = $query->fetch()){
   
	 $_SESSION['email'] = $row['email'];
	 
		
    header("Location: dashboard.php");
} else{
    echo "Something went wrong!";
}

?>