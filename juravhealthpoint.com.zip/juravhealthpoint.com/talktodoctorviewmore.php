<?php include("header.php"); ?>
<body>
<div class ="container">
  <div class="jumbotron" class="background-color:DodgerBlue"> 
  <h1>Work is in progress</h1> 
  <p> 
  Now the services is manually available.Visit to clinic at D-178 New ashok Nagar New Delhi-96.
  <p/>
  </div>
  <div>
   <div class="row">
   
  <div class="col-sm-5" class ="container">
  <div class="jumbotron"  >
  <h1>Online Consultancy Fee-200/Rs  </h1>
  <p> 
  <p>1. Scan Barcode and Pay Fees </p>
  <p>2. Fill the         form with detail </p>
  <p>3. Our Team will arrange the doctor to consult with video/Audio call.</p>
  </p>
  <a class="btn btn-style btn-white mt-sm-5 mt-4 mr-2" href="about.html"> Book Appointment Now</a>
   </div>
   </div>
   
  <div class="col-sm-5" class ="container">
  <div class="jumbotron"  >
  <h2>Physiotherpay Consultancy Fee-500/Rs  </h2>
  <p> 
  <p>1. Scan Barcode and Pay Fees </p>
  <p>2. Fill the form with detail </p>
  <p>3. Our Team will arrange the doctor to consult with video/Audio call.</p>
  <a class="btn btn-style btn-white mt-sm-5 mt-4 mr-2" href="about.html"> Book Appointment Now</a>
  </p>
   </div>
   </div>
   
  <div class="col-sm-5" class ="container">
  <div class="jumbotron"  >
  <h3>Online Payment-Detail  </h3>
  <p>A/C No:-008563300007841</p>
  <p>Bank Name:- JURAV HEALTH POINT PVT LTD.</p>
  <p>IFSC Code:-YESB0000085</p>
  <p> UPI Payment-  juravhealthpoint@paytm.com</p>
  
   </div>
   </div
  
  <div class="col-sm-7" class ="container">
  <div class="jumbotron"  >
  <h3>SACN BARCODE </h3>
  <img src="healthpintbarcode.jpeg" width="400" height="400"></img>
   </div>
   </div>
   </div>
 </div>
 
</body
<?php include("footer.php"); ?>
  