var name = "";
var checkname = function(){
     var name = $("#name").val();
     $('#checking').html("");
	 if(name!=""){
	 	$('#checking').html("<p>Checking....</p>");
	 	$.ajax({
	      url: "check.php",
	      type: 'GET',
	      data: {name : name},
	      success: function(data) {  
	      	$('#checking').html("");
			if(data=="Available"){
				
				$('#checking').html('<p class="bg-success">News Title is not  Exist Please Insert</p>');
			}else{
				
				$('#checking').html('<p class="bg-danger">This News Title Already Exist Please Choose Defferent</p>');
			}
	  },
	  	  error: function(e) {
		 		$('#checking').html('<p class="bg-danger">There was an error</p>');
		}
	});

 }
}

