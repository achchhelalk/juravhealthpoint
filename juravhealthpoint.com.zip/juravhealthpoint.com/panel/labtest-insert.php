 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                     <?php
require 'dbconfig.php';
if(isset($_POST['submit']))
{
//print_r("lavlesh");
//echo "<pre>"; print_r($_POST); exit;
$name= $_POST['name'];
$total_lab_test= $_POST['total_lab_test'];
$lab_test_price= $_POST['lab_test_price'];
$discount_lab_test_price= $_POST['discount_lab_test_price'];
$percentage_discount_lab_test_price= $_POST['percentage_discount_lab_test_price'];
$describtion= $_POST['describtion'];

$image= $_FILES['image']['name'];
$image_tmp= $_FILES['image']['tmp_name'];
$lab_test_file= $_FILES['lab_test_file']['name'];
$lab_test_file_tmp= $_FILES['lab_test_file']['tmp_name'];
try
		{
			$stmt = $pdo->prepare("INSERT INTO labtest(name,total_lab_test,lab_test_price,discount_lab_test_price,
			percentage_discount_lab_test_price,describtion,image,lab_test_file) 
			VALUES(:name,:total_lab_test,:lab_test_price,:discount_lab_test_price,
			:percentage_discount_lab_test_price,:describtion,:image,:lab_test_file)");
			$stmt->bindparam(":name",$name); 
			$stmt->bindparam(":total_lab_test",$total_lab_test); 
			$stmt->bindparam(":lab_test_price",$lab_test_price); 
			$stmt->bindparam(":discount_lab_test_price",$discount_lab_test_price); 
			$stmt->bindparam(":percentage_discount_lab_test_price",$percentage_discount_lab_test_price); 
		$stmt->bindparam(":describtion",$describtion);
		$stmt->bindparam(":image",$image);
		$stmt->bindparam(":lab_test_file",$lab_test_file);
			
			move_uploaded_file($image_tmp,"../labtest/$image");
			move_uploaded_file($lab_test_file_tmp,"../labtest/$lab_test_file");
			
			if($stmt->execute()){
			
			echo "<script>alert('Lab Test Has been inserted')</script>";
	echo "<script>window.open('manage-labtest.php','_self')</script>";
			
			}
			
			else{}
					
			
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

                     
                     
                     
                     
                     
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Insert Lab Test</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Lab Test
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                            
                                        <div class="form-group">
                                            <label>Lab Test Name</label>
                                            <input class="form-control" type="text" name="name">
                                                                                  </div>
                                          <div class="form-group">
                                            <label>Total Lab Tests</label>
                                            <input class="form-control" type="text" name="total_lab_test">
                                                                                 </div>
                                                                                  <div class="form-group">
                                            <label>Lab Tests Price</label>
                                            <input class="form-control" type="text" name="lab_test_price">
                                            </div>
                                            <div class="form-group">
                                            <label>Discount Lab Tests Price</label>
                                            <input class="form-control" type="text" name="discount_lab_test_price">
                                            </div>
                                        <div class="form-group">
                                            <label>Percentage Discount Lab Tests Price</label>
                                            <input class="form-control" type="text" name="percentage_discount_lab_test_price">
                                            </div>
                                        <div class="form-group">
                                            <label>Image</label>
                                            <input class="form-control" type="file" name="image">
                                          
                                        </div>
										 <div class="form-group">
                                            <label>Total Lab Test Report File</label>
                                            <input class="form-control" type="file" name="lab_test_file">
                                          
                                        </div>
                                                                                    <div class="form-group">
                                            <label>Describtion</label>
                                            <textarea class="form-control ckeditor" rows="3" name="describtion"></textarea>
                                        </div>
                                  
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>


</body>
</html>
