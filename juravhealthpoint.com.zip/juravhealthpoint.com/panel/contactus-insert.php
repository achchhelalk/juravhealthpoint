 <?php 
 ob_start();
 include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                    <?php
require 'dbconfig.php';					 
 if(isset($_POST['submit']))

{
$name						= $_POST['name'];

$email				= $_POST['email'];
$phone					= $_POST['phone'];
$describtion 					= $_POST['describtion'];

try
		{
			$stmt = $pdo->prepare("INSERT INTO contactus(name,email,phone,describtion) VALUES(:name,:email,:phone,:describtion)");
			$stmt->bindparam(":name",$name);
		       $stmt->bindparam(":email",$email);
		       $stmt->bindparam(":phone",$phone);
		       $stmt->bindparam(":describtion",$describtion);
			if($stmt->execute()){
				
echo "<script>alert('Contactus Has been successfully insert')</script>";
	echo "<script>window.open('manage-contactus.php','_self')</script>";	
		}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Insert Contact US</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Contactus
                        </div>
                        <div class="panel-body">
                            <form role="form"  method="post" enctype="multipart/form-data">
                            
                                        <div class="form-group">
                                            <label> Address Name</label>
                                            <input class="form-control" type="text" name="name" value="">
                                          
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" type="text" name="email" value="">
                                            
                                                     </div>
                                                                                <div class="form-group">
                                            <label>Phone</label>
                                            <input class="form-control" type="text" name="phone" value="">
                                            
                                                     </div>
                                        
                                        
                                        
                                
                                            <div class="form-group">
                                            <label>Detail in address</label>
                                            <textarea class="form-control ckeditor" rows="3" name="describtion" value=""></textarea>
                                        </div>
                                  
                                 
                                        <button type="submit" class="btn btn-info"  name="submit">Submit </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>

</body>
</html>
