
<?php 
include("dbconfig.php"); 

if(isset($_GET['del'])){

	$delete_id = $_GET['del'];
	
	$delete_query = $pdo->prepare("delete from training_center where id='".$delete_id."' ");
	
	if($delete_query->execute()){
	
	echo "<script>alert('training center Has been Deleted')</script>";
	echo "<script>window.open('manage-training-center.php','_self')</script>";
	
	}
	



}




?>