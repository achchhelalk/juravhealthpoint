  <?php include("header.php"); ?>
  
  <!-- main-slider -->
  <section class="w3l-main-slider" id="home">
    <div class="companies20-content">
      <div class="owl-one owl-carousel owl-theme">
              <?php include('dbconfig.php');$i=0;
			   $fetch=$pdo->prepare("select * from banner order by id desc");
			   $fetch->execute();
			   while($row= $fetch->fetch()){
			   
			   ?>
        <div class="item">
          <li>
            <div class="slider-info banner-view bg bg2">
                <img src="banner/<?php echo $row['image'];?>" class="img-responsive" />
              <div class="banner-info">
                <div class="container">
                  <div class="banner-info-bg">
                    <p><?php echo $row["describtion"];?></p>
                    <h5><?php echo $row["name"];?></h5>
                    <a class="btn btn-style btn-white mt-sm-5 mt-4 mr-2" href="talktdconsultform.php"> Book Appointment Now</a>
                    <a class="btn btn-style border-btn mt-sm-5 mt-4" href="talktdconsultform.php"> Contact Us</a>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </div>
  <?php } ?>
      </div>
    </div>
  </section>
  <!-- /main-slider -->
  <!--/grids-->
  <section class="w3l-grids-3 py-5" id="talk">
    <div class="container py-md-5 py-3">
      <div class="row bottom-ab-grids align-items-center">

        <div class="col-lg-6 bottom-ab-left">
          <h1 class="sub-titlehny">Talk to Doctor</h1>
          <h3 class="hny-title"></h3>
          <div class="separatorhny"></div>
          <p class="my-3">Consult with experinced doctor online /offline. </p>
          <a href="talktodoctorviewmore.php" class="btn btn-style btn-primary mt-4">View More</a>
        </div>
        <div class="col-lg-6 bottom-ab-right mt-lg-0 mt-5 pl-lg-4">
          <img src="assets/images/2.jpg" alt="" class="img-fluid">
        </div>

      </div>
    </div>
  </section>
  <!--//grids-->
   <!--//news-grids-->
  <section class="w3l-news-sec" id="lab">
    <div class="news-mainhny py-5">
      <div class="container text-center py-lg-3">
        <div class="title-content text-center mb-lg-5 mb-4">
          <h6 class="sub-titlehny"></h6>
          <h3 class="hny-title">
           Our Lab Tests</h3>
          <div class="separatorhny"></div>
        </div> 
      </div>
      <div class="owl-news owl-carousel owl-theme">
	   <?php include('dbconfig.php');$i=0;
			   $fetchb=$pdo->prepare("select * from labtest order by id desc");
			   $fetchb->execute();
			   while($rowb= $fetchb->fetch()){
			   
			   ?>
        <div class="item">
          <div class="news-img position-relative">
                <a href="#">
                <h4 class="title text-center"><?php echo $rowb["name"];?></h4><span><?php echo $rowb["total_lab_test"];?> Lab Tests</span>
              </a>
            <a href="#"><img src="labtest/<?php echo $rowb['image'];?>" class="img-fluid" alt="news image"></a>
            <div class="title-wrap">
              <a href="#">
                <span class="title">Rs.<?php echo $rowb["lab_test_price"];?>/- &nbsp; Rs.<?php echo $rowb["discount_lab_test_price"];?>&nbsp; &nbsp;<?php echo $rowb["percentage_discount_lab_test_price"];?>% off</span>
              </a>
            <button class="btn btn-white btn-primary mr-2 clickLabtest">Add</button>
            </div>
          </div>
        </div>
			   <?php } ?>
      
	  
      </div>
    </div>
  </section>
  <!--//news-grids-->
  <!--/features-->
  <section class="w3l-ab-features py-5">
    <div class="container py-md-5 py-3">
      <div class="row features-w3pvt-main" id="features">
        <div class="col-lg-4 col-md-6 feature-gird">
          <div class="row features-hny-inner-gd">
            <div class="col-md-2 col-2 featured_grid_left">
              <div class="icon-hnynumber">
                <span class="hnynumber">01</span>
              </div>
            </div>
            <div class="col-md-10 col-10 featured_grid_right_info">
              <h4><a class="link-hny" href="#url">Our Specialties</a></h4>
              <p>Jaurav Health Point Provides the latest technology & medical procedures in all its units. The team of reputed doctors, nurses and healthcare professionals ensure that quality care at affordable costs is always delivered to the patients.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 feature-gird mt-md-0 mt-4">
          <div class="row features-hny-inner-gd">
            <div class="col-md-2 col-2 featured_grid_left">
              <div class="icon-hnynumber">
                <span class="hnynumber">02</span>
              </div>
            </div>
            <div class="col-md-10 col-10 featured_grid_right_info">
              <h4><a class="link-hny" href="#url">24 Hour Service</a></h4>
              <p>The hospital provides round-the-clock emergency services, with a facility that is fully equipped and managed by a dedicated team of qualified emergency care professionals.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 feature-gird mt-lg-0 mt-md-5 mt-4">
          <div class="row features-hny-inner-gd">
            <div class="col-md-2 col-2 featured_grid_left">
              <div class="icon-hnynumber">
                <span class="hnynumber">03</span>
              </div>
            </div>
            <div class="col-md-10 col-10 featured_grid_right_info">
              <h4><a class="link-hny" href="#url">
                  Free Camp -Every Sunday</a></h4>
              <p>Every Sunday free camp is organised by Jurav Foundation Team. TSH, Sugar Fasting/PP/RR (By strip) and ECG are free.The facilities are only available offline from 8:30AM to 12:00PM </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--//features-->
  <!-- middle 
  <div class="w3l-middle py-5">
    <div class="container py-xl-5 py-lg-3">
      <div class="welcome-left py-3">
        <h6 class="sub-titlehny">Trusted Care.</h6>
        <h4>The right choice for your health care needs.</h4>
        <div class="separatorhny"></div>
        <p class="pr-lg-5">Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt ut
          labore et dolore magna aliqua. </p>
        <div class="buttons mt-5">
          <a href="about.html" class="btn btn-white btn-primary mr-2">Read More</a>
          <a href="contact.html" class="btn btn-style border-btn ml-2">Get a quote</a>
        </div>
      </div>
    </div>
  </div>
  <!-- //middle -->
  <!--/w3l-cwp4
  <div class="w3l-cwp4-sec py-5">
    <div class="container py-md-5 py-3">
      <div class="cwp4-two row align-items-center">
        <div class="cwp4-image col-lg-6 pr-lg-5">
          <img src="assets/images/6.jpg" class="img-fluid" alt="">
        </div>
        <div class="cwp4-text col-lg-6 mt-lg-0 mt-5">
          <h6 class="sub-titlehny">Choose confidently</h6>
          <h3 class="hny-title">
            Caring for our region’s most precious resource</h3>
          <div class="separatorhny"></div>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt ut labore et
            dolore magna aliqua.
          </p>

          <ul class="cont-4 mt-lg-6 mt-md-5 mt-4">
            <li class="subhny-gd mt-sm-0 mt-4">
              <span class="fa fa-user-md"> </span>
              <h4><a class="link-hny" href="#url">
                  Expert Doctors</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicingelit</p>

            </li>
            <li class="subhny-gd mt-sm-0 mt-4">
              <span class="fa fa-trophy"> </span>
              <h4><a class="link-hny" href="#url">
                  Award Winner</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicingelit</p>

            </li>
          </ul>
        </div>

      </div>
    </div>

  </div>
  <!--//w3l-grids-->
  <!-- stats 
  <section class="w3l-stats py-lg-0 py-5" id="stats">
    <div class="gallery-inner container py-lg-0 py-3">
      <div class="row stats-con">
        <div class="col-lg-3 col-6 stats_info counter_grid">
          <span class="fa fa-users"></span>
          <p class="counter">1100</p>
          <h4>Expert Doctors</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid1">
          <span class="fa fa-laptop"></span>
          <p class="counter">1020</p>
          <h4>Health Programs</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid mt-lg-0 mt-5">
          <span class="fa fa-smile-o"></span>
          <p class="counter">912</p>
          <h4>Happy Clients</h4>
        </div>
        <div class="col-lg-3 col-6 stats_info counter_grid2 mt-lg-0 mt-5">
          <span class="fa fa-trophy"></span>
          <p class="counter">80</p>
          <h4>Success Meets</h4>
        </div>
      </div>
    </div>
  </section>
  <!-- //stats -->

  <!-- /blog-posts
  <section id="grids5-block" class="w3l-blogluxe-hny py-5">
    <div class="container py-md-5">
      <div class="row grid-view">
        <div class="col-lg-5 pr-lg-5">
          <h6 class="sub-titlehny">The Power to Heal</h6>
          <h3 class="hny-title">The perfect balance between Health & Care.</h3>
          <div class="separatorhny"></div>
          <p class="my-3">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur hic odio voluptatem
            tenetur consequatur primis. </p>
          <a href="about.html" class="btn btn-style btn-primary mt-4">Read More</a>
        </div>
        <div class="col-lg-7 mt-lg-0 mt-4">
          <div class="row grids5-info">
            <div class="col-6">
              <a href="#" class="zoom">
                <img src="assets/images/s1.jpg" alt="" class="img-fluid" />
              </a>
            </div>
            <div class="col-6">
              <a href="#" class="zoom">
                <img src="assets/images/s2.jpg" alt="" class="img-fluid" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- //blog-Section -->
 
  <!--/w3l-subscribe
  <section class="w3l-subscribe-content py-5">
    <div class="container py-md-4 py-3 text-center">
      <div class="row my-lg-4 mt-4">
        <div class="col-lg-9 col-md-10 mx-auto">
          <div class="subscribe mx-auto">
            <div class="header-section text-center mx-auto">
              <h6 class="sub-titlehny">Join Us</h6>
              <h3 class="hny-title">Stay Updated! </h3>
              <div class="separatorhny"></div>
              <p class="my-3">Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio
                consectetur adipisicing.
                turpis sodales quis. Integer sit amet mattis quam.</p>
            </div>
            <form action="#" method="post" class="subscribe-wthree pt-2 mt-5">
              <div class="d-md-flex flex-wrap subscribe-wthree-field">
                <input class="form-control" type="email" placeholder="Enter your email..." name="email" required="">
                <button class="btn btn-style btn-primary" type="submit">Subscribe</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--//w3l-subscribe-->
<?php include("footer.php"); ?>