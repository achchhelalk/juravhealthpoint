 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                     <?php
require 'dbconfig.php';
if(isset($_POST['submit']))
{
	$regno					= $_POST['regno'];
	$father_name					= $_POST['father_name'];
	$name					= $_POST['name'];
	$dob					= $_POST['dob'];
$session						= $_POST['session'];
$course					= $_POST['course'];
$mother_name						= $_POST['mother_name'];
$branch						= $_POST['branch'];
$address					= $_POST['address'];
$percentage					= $_POST['percentage'];
$mark_obtained				= $_POST['mark_obtained'];
$total_mark				= $_POST['total_mark'];
$result					= $_POST['result'];
$subjecta				= $_POST['subjecta'];
$marka				= $_POST['marka'];
$total_marka				= $_POST['total_marka'];
$subjectb				= $_POST['subjectb'];
$markb				= $_POST['markb'];
$total_markb				= $_POST['total_markb'];
$subjectc				= $_POST['subjectc'];
$markc				= $_POST['markc'];
$total_markc				= $_POST['total_markc'];
$subjectd				= $_POST['subjectd'];
$markd				= $_POST['markd'];
$total_markd				= $_POST['total_markd'];
$subjecte				= $_POST['subjecte'];
$marke				= $_POST['marke'];
$total_marke				= $_POST['total_marke'];
$subjectf				= $_POST['subjectf'];
$markf				= $_POST['markf'];
$total_markf				= $_POST['total_markf'];
$subjectg				= $_POST['subjectg'];
$markg				= $_POST['markg'];
$total_markg				= $_POST['total_markg'];
$subjecth			= $_POST['subjecth'];
$markh			= $_POST['markh'];
$total_markh				= $_POST['total_markh'];
$subjecti				= $_POST['subjecti'];
$marki				= $_POST['marki'];
$total_marki				= $_POST['total_marki'];
$subjectj				= $_POST['subjectj'];
$markj				= $_POST['markj'];
$total_markj				= $_POST['total_markj'];




try
		{
		
			 $stmt = $pdo->prepare("INSERT INTO candidate_registration(regno,father_name,name,dob,session,course,mother_name,
			branch,address,percentage,mark_obtained,total_mark,result,subjecta,
			subjectb,subjectc,subjectd,subjecte,subjectf,subjectg,subjecth,subjecti,
			subjecth,marka,markb,markc,markd,marke,markf,markg,markh,marki,markj,total_marka,
			total_markb,total_markc,total_markd,total_marke,total_markf,total_markg,
			total_markh,total_marki,total_markj) 
			VALUES(:regno,:session,:name,:father_name,:dob,:mother_name,:course,:branch,:address,:percentage,:result,:mark_obtained,:total_mark,:subjecta
,:subjectb,:subjectc,:subjectd,:subjecte,:subjectf,:subjectg,:subjecth,:subjecti,:subjectj,:marka,:markb,:markc,:markd,:marke,:markf,:markg,:markh,:marki,:markj,:total_marka
,:total_markb,:total_markc,:total_markd,:total_markf,:total_markg,:total_markh,:total_marki,:total_markj)");
			$stmt->bindparam(":regno",$regno);
				$stmt->bindparam(":father_name",$father_name);
					$stmt->bindparam(":name",$name);
				$stmt->bindparam(":dob",$dob);
				$stmt->bindparam(":session",$session); 
					$stmt->bindparam(":course",$course);
					$stmt->bindparam(":mother_name",$mother_name); 
		$stmt->bindparam(":branch",$branch);
			$stmt->bindparam(":address",$address);
		$stmt->bindparam(":percentage",$percentage);
					$stmt->bindparam(":mark_obtained",$mark_obtained);
			$stmt->bindparam(":total_mark",$total_mark);
			$stmt->bindparam(":result",$result); 
			$stmt->bindparam(":subjecta",$subjecta);
			$stmt->bindparam(":marka",$marka);
			$stmt->bindparam(":total_marka",$total_marka);
			$stmt->bindparam(":subjectb",$subjectb);
			$stmt->bindparam(":markb",$markb);
			$stmt->bindparam(":total_markb",$total_markb);
			$stmt->bindparam(":subjectc",$subjectc);
			$stmt->bindparam(":markc",$markc);
			$stmt->bindparam(":total_markc",$total_markc);
			$stmt->bindparam(":subjectd",$subjectd);
			$stmt->bindparam(":markd",$markd);
			$stmt->bindparam(":total_markd",$total_markd);
			$stmt->bindparam(":subjecte",$subjecte);
			$stmt->bindparam(":marke",$marke);
			$stmt->bindparam(":total_marke",$total_marke);
			$stmt->bindparam(":subjectf",$subjectf);
			$stmt->bindparam(":markf",$markf);
			$stmt->bindparam(":total_markf",$total_markf);
			$stmt->bindparam(":subjectg",$subjectg);
			$stmt->bindparam(":markg",$markg);
			$stmt->bindparam(":total_markg",$total_markg);
			$stmt->bindparam(":subjecth",$subjecth);
			$stmt->bindparam(":markh",$markh);
			$stmt->bindparam(":total_markh",$total_markh);
			$stmt->bindparam(":subjecti",$subjecti);
			$stmt->bindparam(":marki",$marki);
			$stmt->bindparam(":total_marki",$total_marki);
			$stmt->bindparam(":subjectj",$subjectj);
			$stmt->bindparam(":markj",$markj);
			$stmt->bindparam(":total_markj",$total_markj);
			
			
				if($stmt->execute()){
						
			 header("Location:manage-candidate.php");
			}
			
			else{}
					
			
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

                     
                     
                     
                     
                     
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Insert Candidate</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Candidate
                        </div>
                        <div class="panel-body">
                            <form name="form"  method="post" enctype="multipart/form-data">
                               <div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
							   <div class="form-group">
                                            <label> Reg No</label>
                                            <input class="form-control" type="text" name="regno">
                                        
                                        </div>
                                        <div class="form-group">
                                            <label> Name</label>
                                            <input class="form-control" type="text" name="name">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Father's Name</label>
                                            <input class="form-control" type="text" name="father_name">
                                        
                                        </div>
										  </div>
										</div>
										
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>DOB</label>
                                            <input class="form-control" type="date" name="dob">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Session</label>
                                            <input class="form-control" type="text" name="session">
                                        
                                        </div>
										  </div>
										</div>
										
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Course</label>
                                            <input class="form-control" type="text" name="course">
                                           </div>
                                        </div>
										
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mother's Name</label>
                                            <input class="form-control" type="text" name="mother_name">
                                           </div>
                                        </div>
										
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Branch</label>
                                            <input class="form-control" type="text" name="branch">
                                           </div>
                                        </div>
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Address</label>
                                            <input class="form-control" type="text" name="address">
                                           </div>
                                        </div>
										
										
										 </div>
										 
										
										 
										
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Percentage</label>
                                            <input class="form-control" type="text" name="percentage">
                                           </div>
                                        </div>
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtained">
                                           </div>
                                        </div>
										 </div>
										 
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark </label>
                                            <input class="form-control" type="text" name="total_mark">
                                           </div>
                                        </div>
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Result </label>
                                            <input class="form-control" type="text" name="result">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="subjecta">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marka">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marka">
                                           </div>
                                        </div>
										</div>
										
										
										
										
										
										
										
										
										
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="subjectb">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markb">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markb">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="subjectc">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markc">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markc">
                                           </div>
                                        </div>
										</div>
                                      
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="subjectd">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markd">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markd">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="subjecte">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marke">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marke">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="subjectf">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markf">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markf">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="subjectg">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markg">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markg">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="subjecth">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markh">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markh">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject9</label>
                                            <input class="form-control" type="text" name="subjecti">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marki">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marki">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject10</label>
                                            <input class="form-control" type="text" name="subjectj">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markj">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markj">
                                           </div>
                                        </div>
										</div>
										
										
										
										
										
										
										
										
										
										
										
										
										
										 </div>
                                 <div class="col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="btn btn-info text-center"  name="submit">Submit </button>
                                  </div>
                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>

</body>
</html>
