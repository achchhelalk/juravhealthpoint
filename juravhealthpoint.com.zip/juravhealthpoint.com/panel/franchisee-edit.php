 <?php include("header.php");?>

                     <?php include("sidebar.php");?>
                     
                     
                    <?php
require 'dbconfig.php';					 $e=$_GET['id'];
					 
					  $query =  $pdo->prepare("SELECT * FROM franchisee WHERE id='$e' ");

$query->execute();
$row = $query->fetch();
 
?>
<?php

if(isset($_POST['submit']))
{
	$partner					= $_POST['partner'];
	$applicant_name					= $_POST['applicant_name'];
	$running_institute					= $_POST['running_institute'];
	
	$name_insitute					= $_POST['name_insitute'];
    $details_of_vocational_training_sectors					= $_POST['details_of_vocational_training_sector'];
	
	$details_of_vocational_training_sector=implode(",",$details_of_vocational_training_sectors);
	//print_r($details_of_vocational_training_sectors);
$full_address						= $_POST['full_address'];
$tahsil					= $_POST['tahsil'];
$district						= $_POST['district'];
$state						= $_POST['state'];
$country					= $_POST['country'];

$pin_code					= $_POST['pin_code'];
$area				= $_POST['area'];
$email				= $_POST['email'];
$website					= $_POST['website'];

$mobile_no				= $_POST['mobile_no'];
$landline_no				= $_POST['landline_no'];
$residence			= $_POST['residence'];

$institute_status				= $_POST['institute_status'];
$institute_franchisee				= $_POST['institute_franchisee'];
$computer_type				= $_POST['computer_type'];
$system_quantity				= $_POST['system_quantity'];

$configuration_of_system				= $_POST['configuration_of_system'];
$internet_connectivity				= $_POST['internet_connectivity'];
$total_no_of_staff				= $_POST['total_no_of_staff'];


try
		{
		
			 $stmt = $pdo->prepare(
			 "UPDATE franchisee  SET partner='".$partner."' ,applicant_name='".$applicant_name."',
    running_institute='".$running_institute."' ,name_insitute='".$name_insitute."',details_of_vocational_training_sector='".$details_of_vocational_training_sector."' ,full_address='".$full_address."',
   tahsil='".$tahsil."' ,district='".$district."',state='".$state."' ,country='".$country."',
    pin_code='".$pin_code."' ,area='".$area."',email='".$email."' ,website='".$website."',
   mobile_no='".$mobile_no."' ,landline_no='".$landline_no."',residence='".$residence."' ,institute_status='".$institute_status."',
    institute_franchisee='".$institute_franchisee."' ,computer_type='".$computer_type."',
	system_quantity='".$system_quantity."' ,configuration_of_system='".$configuration_of_system."',
   internet_connectivity='".$internet_connectivity."' ,total_no_of_staff='".$total_no_of_staff."'
  	WHERE id=".$_GET['id']." "
			);
			
			
			
				if($stmt->execute()){
				$id = $pdo->lastInsertId();
      //$succ_msg="Your record Has been successfully added";
	   echo "<script>alert('Your record Has been successfully updated')</script>";
	   echo "<script>window.open('manage-franchisee','_self')</script>";				
			 //header("Location:manage-candidate.php");
			}
			
			else{}
					
			
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Franchise</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Insert Download
                        </div>
                        <div class="panel-body">
                           <div class="col-sm-12 col-md-12 col-xs-12  services-right-grid" style="height:1200px;">
							
	   <form method="post" action="" class="form-horizontal" enctype="multipart/form-data" >
	     <div class="table-responsive">
            <table width="100%" border="1" style="" class="table table-striped table-bordered table-hover">
    <tr>
            <td colspan="4" style="color:black;font-weight:600;padding-left:5px;border-bottom:3px solid grey;height:35px;background-color:#F4F4F4;">Online application for Vocational Training Center</td>
    </tr>            
     
    <tr>
      
        <td><input type="radio" name="partner" value="State Coordinator" <?php if($row['partner'] == 'State Coordinator'){echo "checked=checked";} ?> />&nbsp;&nbsp; State Coordinator </td>   
        <td>&nbsp;&nbsp;<input type="radio" name="partner" id="franchisee" value="Vocational Training Center" <?php if($row['partner'] == 'Vocational Training Center'){echo "checked=checked";} ?> />&nbsp;&nbsp;Vocational Training Center</td>
        <td>&nbsp;&nbsp;<input type="radio" name="partner" id="franchisee" value="Skill Coordinator" <?php if($row['partner'] == 'Skill Coordinator'){echo "checked=checked";} ?> />&nbsp;&nbsp;Skill Coordinator</td>
    </tr>   
    <tr>
      
        <td style="background-color:#F4F4F4;" colspan="1">Name of the Applicant's</td>
        <td colspan="2"><input type="text" name="applicant_name" placeholder="Enter Your Name" style="width:80%;margin-left:14px;padding-left:5px;" value="<?php echo $row['applicant_name'];?>"></td>        
    </tr>
    <tr>
        
        <td style="background-color:#F4F4F4;" colspan="1">Where you are currently running a institute</td>
        <td colspan="">&nbsp;&nbsp;<input type="radio" name="running_institute" id="yn" value="Yes" <?php if($row['running_institute'] == 'Yes'){echo "checked=checked";} ?> />&nbsp;&nbsp;Yes</td>
        <td colspan=""> &nbsp;&nbsp;<input type="radio" name="running_institute" id="yn" value="No" <?php if($row['running_institute'] == 'No'){echo "checked=checked";} ?> />&nbsp;&nbsp;No</td>            
    </tr>
    <tr>
            <td style="background-color:#F4F4F4;" colspan="1">If yes them name of the institute</td>
        <td colspan="2"><input type="text" name="name_insitute" placeholder="If yes them name of the institute" style="width:80%;margin-left:14px;padding-left:5px;" value="<?php echo $row['name_insitute'];?>"></td>
    </tr>
	 <tr>
        <td colspan="4" style="color:black;font-weight:600;padding-left:5px;border-bottom:3px solid grey;height:35px;background-color:#F4F4F4;">Details of Vocational Training Sector</td>
    </tr>
    <tr>
           <td colspan="4">
		   <?php echo $row['details_of_vocational_training_sector'];?>&nbsp;&nbsp;
          <select type="text" name="details_of_vocational_training_sector[]" multiple class="chosen-select" >
		  <option value="Agriculture Sector">Agriculture Sector</option>
		   <option value="Acting and Danc,Music Sector">Acting and Danc,Music Sector</option>
		   <option value="Art & Craft Sector">Art & Craft Sector</option>
		   <option value="Automobile Sector">Automobile Sector</option>
		    <option value="Aviation Sector">Aviation Sector</option>
		    <option value="Ayurveda Sector">Ayurveda Sector</option>
		   <option value="Beauty and Wellness Sector">Beauty and Wellness Sector</option>
		   <option value="Business & Commerce Sector">Business & Commerce Sector</option>
		   <option value="Civil & Agriculture Sector">Civil & Agriculture Sector</option>
		    <option value="Communication & soft skills Sector">Communication & soft skills Sector</option>
		   <option value="Fashion Designing & Apparel Sector">Fashion Designing & Apparel Sector</option>
		   <option value="Fire Sefety & Health Envoirment Sector">Fire Sefety & Health Envoirment Sector</option>
		   <option value="Food processing Sector">Food processing Sector</option>
		    <option value="Health & Paramedical Sector">Health & Paramedical Sector</option>
		   <option value="Hotel management Hospitality & Tourisam Sector">Hotel management Hospitality & Tourisam Sector</option>
		   <option value="Interior & Exterior Designing Sector">Interior & Exterior Designing Sector</option>
		   <option value="IT & Computer Sector">IT & Computer Sector</option>
		    <option value="Media & Mass Communiaction Sector">Media & Mass Communiaction Sector</option>
		   <option value="Shipping,Logistic & Transport Sector">Shipping,Logistic & Transport Sector</option>
		   <option value="Social Work & NGO Sector">Social Work & NGO Sector</option>
		   <option value="Sports Sector">Sports Sector</option>
		    <option value="Unani & Siddha Sector">Unani & Siddha Sector</option>
		   <option value="Veteinary Sector">Veteinary Sector</option>
		   <option value="Yoga & Naturopathy Sector">Yoga & Naturopathy Sector</option>
		   <option value="Machanical & RAC Sector">Machanical & RAC Sector</option>
		   
		  </select>
                    
        </td>
    </tr>
        <tr>
        <td colspan="4" style="color:black;font-weight:600;padding-left:5px;border-bottom:3px solid grey;background-color:#F4F4F4;height:35px;">Complete Address</td>
    </tr>       
    <tr>
       
        <td><input type="text" name="full_address" placeholder="Enter Full Address" style="width:98%;padding-left:5px;margin-left:2px;" value="<?php echo $row['full_address'];?>"></td>
        <td><input type="text" name="tahsil" placeholder="Tahsil" style="width:98%;padding-left:5px;margin-left:2px;" value="<?php echo $row['tahsil'];?>"></td>
        <td><input type="text" name="district" placeholder="District" style="width:98%;padding-left:5px;margin-left:2px;" value="<?php echo $row['district'];?>"></td>
    </tr>
    <tr>
        
        <td><input type="text" name="state" placeholder="State" style="width:98%;padding-left:5px;margin-left:2px;" value="<?php echo $row['state'];?>"></td>
        <td><input type="text" name="country" placeholder="Country" style="width:98%;padding-left:5px;margin-left:2px;" value="<?php echo $row['country'];?>"></td>
        <td><input type="text" name="pin_code" placeholder="Pin Code" style="width:98%;padding-left:5px;margin-left:2px;" value="<?php echo $row['pin_code'];?>"></td>
    </tr>
    <tr rowspan="5">
       
        &nbsp;        <td style="background-color:#F4F4F4;">Area</td>                <td colspan="3">
        &nbsp;<input type="radio" name="area" id="Area" value="Urban" <?php if($row['area'] == 'Urban'){echo "checked=checked";} ?>/>&nbsp;Urban&nbsp;&nbsp;&nbsp;
        <input type="radio" name="area" id="Area" value="Semi Urban" <?php if($row['area'] == 'Semi Urban'){echo "checked=checked";} ?> />&nbsp;Semi Urban&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="area" id="Area" value="Rural" <?php if($row['area'] == 'Rural'){echo "checked=checked";} ?>  />&nbsp;Rural&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="radio" name="area" id="Area" value="City" <?php if($row['area'] == 'City'){echo "checked=checked";} ?> />&nbsp;City</td>
    </tr>
         <tr>
         <td colspan="4" style="color:black;font-weight:600;padding-left:5px;border-bottom:3px solid grey;height:35px;background-color:#F4F4F4;">Website | Email Id's</td>
     </tr>  
     <tr>
       
        <td colspan="" style="background-color:#F4F4F4;">Email  ID &nbsp;&nbsp; -
        <input type="text" name="email" value="<?php echo $row['email'];?>"  placeholder="Enter Email"  required></td>
        <td  colspan="" style="background-color:#F4F4F4;">Website&nbsp;&nbsp;-
       <input type="text" name="website" value="<?php echo $row['website'];?>" placeholder="Enter Website"  required></td>
        
    </tr>        
    <tr> 
           <td colspan="4" style="color:black;font-weight:600;padding-left:5px;border-bottom:3px solid grey;height:35px;background-color:#F4F4F4;">Contact Details</td>
    </tr>
    <tr>
            
            <td style="background-color:#F4F4F4;"><input type="number" name="mobile_no" value="<?php echo $row['mobile_no'];?>"  placeholder="Mobile No." required></td>
            <td style="background-color:#F4F4F4;"><input type="number" name="landline_no" value="<?php echo $row['landline_no'];?>"  placeholder="Landline No."></td>
            <td style="background-color:#F4F4F4;"><input type="text" name="residence" value="<?php echo $row['residence'];?>" placeholder="Residence"></td>        
    </tr>
    <tr>   
            <td colspan="4" style="color:black;font-weight:600;padding-left:5px;border-bottom:3px solid grey;background-color:#F4F4F4;height:35px;">Institute Detail</td>
     </tr>
     <tr>
             
             <td style="background-color:#F4F4F4;">Status of The Institute</td>
             <td colspan="3">
             &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="institute_status" value="Trust" <?php if($row['institute_status'] == 'Trust'){echo "checked=checked";} ?> />&nbsp;Trust&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" name="institute_status" id="instsatus" value="Private Limited" <?php if($row['institute_status'] == 'Private Limited'){echo "checked=checked";} ?> />&nbsp;Pvt.Ltd&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="radio" name="institute_status" id="instsatus" value="Society" <?php if($row['institute_status'] == 'Society'){echo "checked=checked";} ?> />&nbsp;Society&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="radio" name="institute_status" id="instsatus" value="Partnership" <?php if($row['institute_status'] == 'Partnership'){echo "checked=checked";} ?> />&nbsp;Partnership
                    </td>
    </tr>
    <tr>
            
            <td colspan="2" style="background-color:#F4F4F4;">Where Your Institute is currently Associated/Franchisee/Partner of Any Orgnization(If Yes Please Specify the Brand</td>
            <td colspan=""><input type="text" name="institute_franchisee" value="<?php echo $row['institute_franchisee'];?>" placeholder="Enter Details" style="width:98%;margin-left:5px;"></td>
    </tr>
          <tr>
          <td colspan="4" style="color:black;font-weight:600;padding-left:5px;background-     color:#F4F4F4;border-bottom:3px solid grey;height:35px;">Computer and Peripherals</td>
      </tr>
      <tr>
          
          <td colspan="3">
           &nbsp;1.&nbsp;<input type="text" name="computer_type" value="<?php echo $row['computer_type'];?>" placeholder="Computer Type">
           &nbsp;2.&nbsp;<input type="number" name="system_quantity" value="<?php echo $row['system_quantity'];?>" placeholder="System quantity">
            &nbsp;3.&nbsp;<input type="text" name="configuration_of_system" value="<?php echo $row['configuration_of_system'];?>" placeholder="Configuration of System">
       </tr>
           <tr>
           <td colspan="4" style="color:black;font-weight:600;padding-left:5px;background-color:#F4F4F4;border-bottom:3px solid grey;height:35px;">Internet Connectivity</td>
      </tr>
      <tr>
          
          <td colspan="3">
          &nbsp;Broad Band&nbsp;&nbsp;<input type="radio" name="internet_connectivity" id="internetc" <?php if($row['internet_connectivity'] == 'Broad Band'){echo "checked=checked";} ?> value="Broad Band">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cabel&nbsp;&nbsp;<input type="radio" name="internet_connectivity" <?php if($row['internet_connectivity'] == 'Cabel'){echo "checked=checked";} ?> id="internetc" value="Cabel">
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;WiFi&nbsp;&nbsp;<input type="radio" name="internet_connectivity" <?php if($row['internet_connectivity'] == 'Wifi'){echo "checked=checked";} ?> id="internetc" value="Wifi">            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Other&nbsp;&nbsp;<input type="radio" name="InternetConnection" id="internetc" value="Other">
                    </td>
    </tr>
         <tr>
        <td colspan="4" style="color:black;font-weight:600;padding-left:5px;border-bottom:3px solid grey;height:35px;background-color:#F4F4F4;">Details of The Faculty Staff</td>
    </tr>
    <tr>
       
        <td style="background-color:#F4F4F4;">Total No. of Staff</td>
            <td colspan="2">
          <input type="text" name="total_no_of_staff" value="<?php echo $row['total_no_of_staff'];?>" placeholder="Number of Staff" style="width:98%;margin-left:5px;">
                    
        </td>
    </tr>
            <tr><td colspan="4" style="height:80px;">
            <center>
             
                
                <button type="submit" name="submit" class="btn btn-primary" style="font-size:18px;">Submit</button>
    </center>
    </td></tr>
        </table>
		</div>
            </form>
        
					</div>
					
					<br><br>
					<div class="clear"></div>
                            
                        
                        </div>
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>



 

	
    
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.jquery.min.js"></script>
<link href="https://cdn.rawgit.com/harvesthq/chosen/gh-pages/chosen.min.css" rel="stylesheet"/>
	<script>
	$(".chosen-select").chosen({
  no_results_text: "Oops, nothing found!"
})
	</script>
    	
	<style>
	.services-right-grid {
          text-align: center;
    background-color: #f5f5f5;
    border: 3px solid #e5e7e9;
    height: 120px;
    margin-right: 3px;
    /* margin-bottom: 100px; */
}
}
.se-top {
    border: 1px solid #e5e7e9;
padding: 40px 40px;
}
    .services-right-grid {
    text-align: center;
}

	</style>
