
<?php 
include("dbconfig.php"); 

if(isset($_GET['id'])){

	$delete_id = $_GET['id'];
	
	
	 $query=$pdo->prepare("delete from enrolment where id='$delete_id' ");
	
	if($query->execute()){
	
	echo "<script>alert('enrolment Has been Deleted')</script>";
	echo "<script>window.open('manage-enrollment.php','_self')</script>";
	
	}
	
}




?>
