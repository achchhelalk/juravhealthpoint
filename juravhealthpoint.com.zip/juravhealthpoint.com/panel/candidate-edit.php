 
 <?php
  ob_start();
    session_start();
  
  
 ini_set('display_errors', 1);
error_reporting(E_ALL ^ E_NOTICE);
  include("header.php");
 
 ?>

                     <?php include("sidebar.php");?>
                     
                     
                     <?php
require 'dbconfig.php';

$id=$_GET['id'];
$query=$pdo->prepare("select * from  candidate_registration where id='$id' ");
$query->execute();
$row=$query->fetch();

if(isset($_POST['submit']))
{
$regno					= $_POST['regno'];
	$name					= $_POST['name'];
	$father_name					= $_POST['father_name'];
	
	$dob					= $_POST['dob'];
$session						= $_POST['session'];
$course					= $_POST['course'];
$mother_name						= $_POST['mother_name'];
$branch						= $_POST['branch'];
$address					= $_POST['address'];
$percentage					= $_POST['percentage'];
$mark_obtained				= $_POST['mark_obtained'];
$total_mark				= $_POST['total_mark'];
$result					= $_POST['result'];
$subjecta				= $_POST['subjecta'];
$marka				= $_POST['marka'];
$total_marka				= $_POST['total_marka'];
$subjectb				= $_POST['subjectb'];
$markb				= $_POST['markb'];
$total_markb				= $_POST['total_markb'];
$subjectc				= $_POST['subjectc'];
$markc				= $_POST['markc'];
$total_markc				= $_POST['total_markc'];
$subjectd				= $_POST['subjectd'];
$markd				= $_POST['markd'];
$total_markd				= $_POST['total_markd'];
$subjecte				= $_POST['subjecte'];
$marke				= $_POST['marke'];
$total_marke				= $_POST['total_marke'];
$subjectf				= $_POST['subjectf'];
$markf				= $_POST['markf'];
$total_markf				= $_POST['total_markf'];
$subjectg				= $_POST['subjectg'];
$markg				= $_POST['markg'];
$total_markg				= $_POST['total_markg'];
$subjecth			= $_POST['subjecth'];
$markh			= $_POST['markh'];
$total_markh				= $_POST['total_markh'];
$subjecti				= $_POST['subjecti'];
$marki				= $_POST['marki'];
$total_marki				= $_POST['total_marki'];
$subjectj				= $_POST['subjectj'];
$markj				= $_POST['markj'];
$total_markj				= $_POST['total_markj'];


$subjectk				= $_POST['subjectk'];
$markk				= $_POST['markk'];
$total_markk				= $_POST['total_markk'];


$suba				= $_POST['suba'];
$markaa				= $_POST['markaa'];
$tota				= $_POST['tota'];
$subb				= $_POST['subb'];
$markbb				= $_POST['markbb'];
$totb				= $_POST['totb'];
$subc				= $_POST['subc'];
$markcc				= $_POST['markcc'];
$totc				= $_POST['totc'];
$subd				= $_POST['subd'];
$markdd				= $_POST['markdd'];
$totd				= $_POST['totd'];
$sube				= $_POST['sube'];
$markee				= $_POST['markee'];
$tote				= $_POST['tote'];
$subf				= $_POST['subf'];
$markff				= $_POST['markff'];
$totf				= $_POST['totf'];
$subg				= $_POST['subg'];
$markgg				= $_POST['markgg'];
$totg				= $_POST['totg'];
$subh			= $_POST['subh'];
$markhh			= $_POST['markhh'];
$toth				= $_POST['toth'];
$subi				= $_POST['subi'];
$markii				= $_POST['markii'];
$toti				= $_POST['toti'];
$subj				= $_POST['subj'];
$markjj				= $_POST['markjj'];
$totj				= $_POST['totj'];

$subk				= $_POST['subk'];
$markkeleven				= $_POST['markkeleven'];
$totk				= $_POST['totk'];

$third_suba				= $_POST['third_suba'];
$third_marka				= $_POST['third_marka'];
$third_tota				= $_POST['third_tota'];
$third_subb				= $_POST['third_subb'];
$third_markb				= $_POST['third_markb'];
$third_totb				= $_POST['third_totb'];
$third_subc				= $_POST['third_subc'];
$third_markc				= $_POST['third_markc'];
$third_totc				= $_POST['third_totc'];
$third_subd				= $_POST['third_subd'];
$third_markd				= $_POST['third_markd'];
$third_totd				= $_POST['third_totd'];
$third_sube				= $_POST['third_sube'];
$third_marke				= $_POST['third_marke'];
$third_tote				= $_POST['third_tote'];
$third_subf				= $_POST['third_subf'];
$third_markf				= $_POST['third_markf'];
$third_totf				= $_POST['third_totf'];
$third_subg				= $_POST['third_subg'];
$third_markg				= $_POST['third_markg'];
$third_totg				= $_POST['third_totg'];
$third_subh			= $_POST['third_subh'];
$third_markh			= $_POST['third_markh'];
$third_toth				= $_POST['third_toth'];
$third_subi				= $_POST['third_subi'];
$third_marki				= $_POST['third_marki'];
$third_toti				= $_POST['third_toti'];
$third_subj				= $_POST['third_subj'];
$third_markj				= $_POST['third_markj'];
$third_totj				= $_POST['third_totj'];




try
		{
					
			$stmt = $pdo->prepare("update candidate_registration SET 	regno='".$regno."' ,name='".$name."',father_name='".$father_name."',dob='".$dob."',session='".$session."' , course='".$course."'   ,
			 mother_name='".$mother_name."',total_mark='".$total_mark."' ,mark_obtained='".$mark_obtained."' ,  branch='".$branch."' ,
			address='".$address."' ,percentage='".$percentage."' ,result='".$result."',subjecta='".$subjecta."' , marka='".$marka."' ,total_marka='".$total_marka."' ,subjectb='".$subjectb."' , markb='".$markb."' ,total_markb='".$total_markb."'
		,subjectc='".$subjectc."' , markc='".$markc."' ,total_markc='".$total_markc."',subjectd='".$subjectd."' , markd='".$markd."' ,total_markd='".$total_markd."'
		,subjecte='".$subjecte."' , marke='".$marke."' ,total_marke='".$total_marke."',subjectf='".$subjectf."' , markf='".$markf."' ,total_markf='".$total_markf."'	
		,subjectg='".$subjectg."' , markg='".$markg."' ,total_markg='".$total_markg."',subjecth='".$subjecth."' , markh='".$markh."' ,total_markh='".$total_markh."'	
		,subjecti='".$subjecti."' , marki='".$marki."' ,total_marki='".$total_marki."',subjectj='".$subjectj."' , markj='".$markj."' ,total_markj='".$total_markj."',totk='".$totk."',		
		subjectk='".$subjectk."' , markk='".$markk."' ,total_markk='".$total_markk."',		
suba='".$suba."' , markaa='".$markaa."' ,tota='".$tota."' ,subb='".$subb."' , markbb='".$markbb."' ,totb='".$totb."'
		,subc='".$subc."' , markcc='".$markcc."' ,totc='".$totc."',subd='".$subd."' , markdd='".$markdd."' ,totd='".$totd."'
		,sube='".$sube."' , markee='".$markee."' ,tote='".$tote."',subf='".$subf."' , markff='".$markff."' ,totf='".$totf."'	
		,subg='".$subg."' , markgg='".$markgg."' ,totg='".$totg."',subh='".$subh."' , markhh='".$markhh."' ,toth='".$toth."'	
		,subi='".$subi."' , marki='".$marki."' ,toti='".$total_marki."',subj='".$subj."' , markjj='".$markjj."' ,totj='".$totj."'
		,subk='".$subk."' , markkeleven='".$markkeleven."' ,totj='".$totj."',
		third_suba='".$third_suba."' , third_marka='".$third_marka."' ,third_tota='".$third_tota."' ,third_subb='".$third_subb."' , third_markb='".$third_markb."' ,third_totb='".$third_totb."'
		,third_subc='".$third_subc."' , third_markc='".$third_markc."' ,third_totc='".$third_totc."',third_subd='".$third_subd."' , third_markd='".$third_markd."' ,third_totd='".$third_totd."'
		,third_sube='".$third_sube."' , third_marke='".$third_marke."' ,third_tote='".$third_tote."',third_subf='".$third_subf."' , third_markf='".$third_markf."' ,third_totf='".$third_totf."'	
		,third_subg='".$third_subg."' , third_markg='".$third_markg."' ,third_totg='".$third_totg."',third_subh='".$third_subh."' , third_markh='".$third_markh."' ,third_toth='".$third_toth."'	
		,third_subi='".$third_subi."' , third_marki='".$third_marki."' ,third_toti='".$third_toti."',third_subj='".$third_subj."' , third_markj='".$third_markj."' ,third_totj='".$third_totj."'
		
		
		
		
		
			WHERE id=".$_GET['id']." ");
			//move_uploaded_file($rollno_tmp,"../rollnos/$rollno");
				//move_uploaded_file($brochure_tmp,"../rollnos/$brochure");
		
			if($stmt->execute()){
			
			
			echo "<script>alert('Candidate record Has been successfully Updated')</script>";
	echo "<script>window.open('manage-candidate.php','_self')</script>";
			}
						else{}
						
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}

?>

                     
                     
                     
                     
                     
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Candidate</h1>
                        <h1 class="page-subhead-line"> </h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               <div class="panel panel-info">
                        <div class="panel-heading">
                       Edit Candidate
                        </div>
                        <div class="panel-body">
                          <form name="form"  method="post" enctype="multipart/form-data">
                               <div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
							   <div class="form-group">
                                            <label> Reg No</label>
                                            <input class="form-control" type="text" name="regno" value="<?php echo $row['regno']; ?>">
                                        
                                        </div>
                                        <div class="form-group">
                                            <label> Name</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo $row['name']; ?>">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Father's Name</label>
                                            <input class="form-control" type="text" name="father_name" value="<?php echo $row['father_name']; ?>">
                                        
                                        </div>
										  </div>
										</div>
										
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
							   <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>DOB</label>
                                            <input class="form-control" type="date" name="dob" value="<?php echo $row['dob']; ?>">
                                        
                                        </div>
										  </div>
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label>Session</label>
                                            <input class="form-control" type="text" name="session" value="<?php echo $row['session']; ?>">
                                        
                                        </div>
										  </div>
										</div>
										
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Course</label>
                                            <input class="form-control" type="text" name="course" value="<?php echo $row['course']; ?>">
                                           </div>
                                        </div>
										
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mother's Name</label>
                                            <input class="form-control" type="text" name="mother_name" value="<?php echo $row['mother_name']; ?>">
                                           </div>
                                        </div>
										
										
										 </div>
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Branch</label>
                                            <input class="form-control" type="text" name="branch" value="<?php echo $row['branch']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>VTP</label>
                                            <input class="form-control" type="text" name="address" value="<?php echo $row['address']; ?>">
                                           </div>
                                        </div>
										
										
										 </div>
										 
										
										 
										
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Percentage</label>
                                            <input class="form-control" type="text" name="percentage" value="<?php echo $row['percentage']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtained</label>
                                            <input class="form-control" type="text" name="mark_obtained" value="<?php echo $row['mark_obtained']; ?>">
                                           </div>
                                        </div>
										 </div>
										 
										 
										  <div class="col-md-12 col-sm-12 col-xs-12">
										  <div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark </label>
                                            <input class="form-control" type="text" name="total_mark" value="<?php echo $row['total_mark']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-6 col-sm-6 col-xs-12">
                                           <div class="form-group">
                                            <label>Result</label>
                                            <input class="form-control" type="text" name="result" value="<?php echo $row['result']; ?>">
                                           </div>
                                        </div>
										 </div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="subjecta" value="<?= $row['subjecta']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marka" value="<?= $row['marka']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marka" value="<?= $row['total_marka']; ?>">
                                           </div>
                                        </div>
										</div>
										
										
										
										
										
										
										
										
										
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="subjectb" value="<?= $row['subjectb']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markb" value="<?= $row['markb']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markb" value="<?= $row['total_markb']; ?>">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="subjectc" value="<?= $row['subjectc']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markc" value="<?= $row['markc']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markc" value="<?= $row['total_markc']; ?>">
                                           </div>
                                        </div>
										</div>
                                      
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="subjectd" value="<?= $row['subjectd']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markd" value="<?= $row['markd']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markd" value="<?= $row['total_markd']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="subjecte" value="<?= $row['subjecte']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marke" value="<?= $row['marke']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marke" value="<?= $row['total_marke']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="subjectf" value="<?= $row['subjectf']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markf" value="<?= $row['markf']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markf" value="<?= $row['total_markf']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="subjectg" value="<?= $row['subjectg']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markg" value="<?= $row['markg']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markg" value="<?= $row['"total_markg']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="subjecth" value="<?= $row['subjecth']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markh" value="<?= $row['markh']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markh" value="<?= $row['total_markh']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject9</label>
                                            <input class="form-control" type="text" name="subjecti" value="<?= $row['subjecti']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="marki" value="<?= $row['marki']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_marki" value="<?= $row['total_marki']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject10</label>
                                            <input class="form-control" type="text" name="subjectj" value="<?= $row['subjectj']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markj" value="<?= $row['markj']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markj" value="<?= $row['total_markj']; ?>">
                                           </div>
                                        </div>
										</div> 
										 
										 
										 <div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject11</label>
                                            <input class="form-control" type="text" name="subjectk" value="<?= $row['subjectk']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markk"  value="<?= $row['markk']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="total_markk"  value="<?= $row['total_markk']; ?>">
                                           </div>
                                        </div>
										</div>
										
										
										
										
										
										
										
										
										
										
										
										
										<!-- first year end form -->
										
									
										<div class="col-md-12 col-sm-12 col-xs-12">
										<h4>Second Year Result</h4>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject1</label>
                                            <input class="form-control" type="text" name="suba"  value="<?= $row['suba']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markaa" value="<?= $row['markaa']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="tota"  value="<?= $row['tota']; ?>">
                                           </div>
                                        </div>
										</div>
										
										
										
										
										
										
										
										
										
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject2</label>
                                            <input class="form-control" type="text" name="subb" value="<?= $row['subb']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markbb" value="<?= $row['markbb']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totb" value="<?= $row['totb']; ?>">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject3</label>
                                            <input class="form-control" type="text" name="subc" value="<?= $row['subc']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markcc" value="<?= $row['markcc']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totc" value="<?= $row['totc']; ?>">
                                           </div>
                                        </div>
										</div>
                                      
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject4</label>
                                            <input class="form-control" type="text" name="subd" value="<?= $row['subd']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markdd" value="<?= $row['markdd']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totd" value="<?= $row['totd']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject5</label>
                                            <input class="form-control" type="text" name="sube" value="<?= $row['sube']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markee" value="<?= $row['markee']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="tote" value="<?= $row['tote']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject6</label>
                                            <input class="form-control" type="text" name="subf" value="<?= $row['subf']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markff" value="<?= $row['markff']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totf" value="<?= $row['totf']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject7</label>
                                            <input class="form-control" type="text" name="subg" value="<?= $row['subg']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markgg" value="<?= $row['markgg']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totg" value="<?= $row['totg']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject8</label>
                                            <input class="form-control" type="text" name="subh" value="<?= $row['subh']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markhh" value="<?= $row['markhh']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="toth" value="<?= $row['toth']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject9</label>
                                            <input class="form-control" type="text" name="subi" value="<?= $row['subi']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markii" value="<?= $row['markii']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="toti" value="<?= $row['toti']; ?>">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject10</label>
                                            <input class="form-control" type="text" name="subj" value="<?= $row['subj']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markjj" value="<?= $row['markjj']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totj" value="<?= $row['totj']; ?>">
                                           </div>
                                        </div>
										</div>
										
										
										
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Subject11</label>
                                            <input class="form-control" type="text" name="subk" value="<?= $row['subk']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="markkeleven" value="<?= $row['markkeleven']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Total Mark</label>
                                            <input class="form-control" type="text" name="totk" value="<?= $row['totk']; ?>">
                                           </div>
                                        </div>
										</div>
										
										
							<!-- end second year end form -->
										<div class="col-md-12 col-sm-12 col-xs-12">
										<h4>Third Year Result</h4>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject1</label>
                                            <input class="form-control" type="text" name="third_suba" value="<?= $row['third_suba']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_marka" value="<?= $row['third_marka']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_tota" value="<?= $row['third_tota']; ?>">
                                           </div>
                                        </div>
										</div>
										
						
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject2</label>
                                            <input class="form-control" type="text" name="third_subb" value="<?= $row['third_subb']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markb" value="<?= $row['third_markb']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totb" value="<?= $row['third_totb']; ?>">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject3</label>
                                            <input class="form-control" type="text" name="third_subc" value="<?= $row['third_subc']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markc" value="<?= $row['third_markc']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totc" value="<?= $row['third_totc']; ?>">
                                           </div>
                                        </div>
										</div>
                                      
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject4</label>
                                            <input class="form-control" type="text" name="third_subd" value="<?= $row['third_subd']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markd" value="<?= $row['third_markd']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totd" value="<?= $row['third_totd']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject5</label>
                                            <input class="form-control" type="text" name="third_sube" value="<?= $row['third_sube']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_marke" value="<?= $row['third_marke']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_tote" value="<?= $row['third_tote']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject6</label>
                                            <input class="form-control" type="text" name="third_subf" value="<?= $row['third_subf']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markf" value="<?= $row['third_markf']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totf" value="<?= $row['third_totf']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject7</label>
                                            <input class="form-control" type="text" name="third_subg" value="<?= $row['third_subg']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markg" value="<?= $row['third_markg']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totg" value="<?= $row['third_totg']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject8</label>
                                            <input class="form-control" type="text" name="third_subh" value="<?= $row['third_subh']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markh" value="<?= $row['third_markh']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_toth" value="<?= $row['third_toth']; ?>">
                                           </div>
                                        </div>
										</div><div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject9</label>
                                            <input class="form-control" type="text" name="third_subi" value="<?= $row['third_subi']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_marki" value="<?= $row['third_marki']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_toti" value="<?= $row['third_toti']; ?>">
                                           </div>
                                        </div>
										</div>
										<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_subject10</label>
                                            <input class="form-control" type="text" name="third_subj" value="<?= $row['third_subj']; ?>">
                                           </div>
                                        </div>
										
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>Mark Obtain</label>
                                            <input class="form-control" type="text" name="third_markj" value="<?= $row['third_markj']; ?>">
                                           </div>
                                        </div>
										<div class="col-md-4 col-sm-4 col-xs-12">
                                           <div class="form-group">
                                            <label>third_total Mark</label>
                                            <input class="form-control" type="text" name="third_totj" value="<?= $row['third_totj']; ?>">
                                           </div>
                                        </div>
										</div>
										
										
										
										



							
										
						<!--third year result end -->				
										
										
													
										 
										 
										 
										 
										 
										 
										 
										 
                                 <div class="col-md-12 col-sm-12 col-xs-12">
                                        <button type="submit" class="btn btn-info text-center"  name="submit">Submit </button>
                                  </div>
                                    </form>
                                 
                            </div>
                        </div>
                            </div>

        </div>
             <!--/.ROW-->
             

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <?php include("footer.php");?>
	
<script type="text/javascript">

 $(document).ready(function() {
        $('.secondry').click(function() {
                $('.secondry_save').toggle("slide");
        });
    });
</script>
<script type="text/javascript">

 $(document).ready(function() {
        $('.third').click(function() {
                $('.third_save').toggle("slide");
        });
    });



</script>



</body>
</html>
